/*   Copyright (c) 2016 by Intellect Design Arena Ltd.
**************************************************************************
* Project Name : APT Module
* Filename     : LabelCache.java
* Brief Desc.  :
*
*
* Maint. Hist. :
*
*  Version		 DATE		  CHANGED BY		CHANGE DESCRIPTION
* ----------  -----------	---------------    --------------------
*	 1.0						-		         New File
*    1.1  		28/03/2017	Mithul Bhansali		Variable added for Cache Refresh
 ******************************************************************************************************************************/


package com.polaris.labelling.utility;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.intellect.hubs.ap.entities.Column;
import com.intellect.hubs.ap.entities.EntityLinkToParent;
import com.intellect.hubs.ap.entities.SystemEntityVo;
import com.intellect.hubs.ap.entities.Table;
import com.polaris.genericmaint.exceptions.FrameWorkSystemException;
import com.polaris.labelling.constant.APTConstant;
import com.polaris.labelling.entity.cache.DependentApplication;
import com.polaris.labelling.entity.cache.EntityActionMasterBean;
import com.polaris.labelling.entity.cache.EntityColumnInfoBean;
import com.polaris.labelling.entity.cache.EntityDetailMasterBean;
import com.polaris.labelling.entity.cache.EntityForeignKeyDetailMasterBean;
import com.polaris.labelling.entity.cache.EntityLinkDetailMasterBean;
import com.polaris.labelling.entity.cache.EntityLinkMasterBean;
import com.polaris.labelling.entity.cache.EntityMasterBean;
import com.polaris.labelling.entity.cache.EntityPrimaryKeyMasterBean;
import com.polaris.labelling.entity.cache.ExportFileDetailsBean;
import com.polaris.labelling.entity.cache.SchemaObjectMetaDataBean;
import com.polaris.labelling.sql.Queries;
import com.polaris.tools.DBResourceUtil;
import com.polaris.workflow.tools.WFLogger;
import com.polaris.workflow.tools.WFMaintConstants;

public class LabelCache {
	
	
	private static WFLogger mLog = WFLogger.getInstance(LabelCache.class.getName());
	//public static Map<String, ApplicationInfoBean> appNameAppInfoBeanMap =null;
	public static Map<String, List<EntityLinkMasterBean>> appTypeEntityLinkMasterBeanMap=null;//EntityTreeInfoBean -> EntityLinkMasterBean
	public static Map<String, List<EntityMasterBean>> entityNameEntityMasterBeanMap=null;//EntityTableInfoBean -> EntityMasterBean
	public static Map<String, List<EntityColumnInfoBean>> tableNameEntityColumnInfoBeanMap=null;	//ColumnInfoBean -> EntityColumnInfoBean
	public static Map<String, List<EntityPrimaryKeyMasterBean>> entityNameEntityPrimaryKeyMasterBeanMap=null;//EntityPrimaryKeyInfoBean -> EntityPrimaryKeyMasterBean
	public static Map<String, List<EntityDetailMasterBean>> entityNameEntityDetailMasterBeanMap=null;
	public static Map<String, List<EntityLinkDetailMasterBean>> entityNameEntityLinkDetailsMasterBeanMap=null;//EntityRelationshipInfoBean -> EntityLinkDetailMasterBean
	//Navin
	public static Map<String, List<EntityForeignKeyDetailMasterBean>> constraintNameEntityForeignKeyDetailsMasterBeanMap=null;//
	public static Map<String, List<SchemaObjectMetaDataBean>> entityNameSchemaObjectMetaDataBeanMap=null;
	public static Map<String, EntityActionMasterBean> actionIdEntityActionMasterBeanMap = null; 
	public static Map<String,Boolean> lblEnvOPerationenableMentMap=null;
	public static Map<String,List<String>> entityExportFileDetailsMap=null;
	public static List<ExportFileDetailsBean> exportFileDetailsBeans=null;
	public static Map<Integer, DependentApplication> applicationIdDependentApplicationBeanMap = null;
	public static Map<String,Map<String,List<EntityLinkDetailMasterBean>>> childAndParentEntityLinkMasterBeanMap=null;	
	public static Map<String, String> appTypeRootEntityMap = null;
	public static Map<String, Map<String, List<String>>> appTypeEntityNameTableNameListMap = null;
	public static Map<String, Map<String, List<String>>> appTypeEntityNameTableNameListDeleteMap = null;	
	public static Map<String,List<EntityLinkDetailMasterBean>>  appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap=null;
	
//	public static void main(String[] args) {
//		Connection conn = null;
//		try {
//			conn = ResourceManager.getConnection();
//		} catch (FrameWorkSystemException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try {
//			Map<String,List<EntityLinkDetailMasterBean>>  appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap=populateAppTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap();
//		} catch (FrameWorkSystemException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	
	public static void refreshLabelCache() {
		//appNameAppInfoBeanMap =null;
		appTypeEntityLinkMasterBeanMap=null;
		entityNameEntityMasterBeanMap=null;
		tableNameEntityColumnInfoBeanMap=null;	
		entityNameEntityPrimaryKeyMasterBeanMap=null;
		entityNameEntityDetailMasterBeanMap=null;
		entityNameEntityLinkDetailsMasterBeanMap=null;
		entityNameSchemaObjectMetaDataBeanMap = null;
		actionIdEntityActionMasterBeanMap = null;
		constraintNameEntityForeignKeyDetailsMasterBeanMap = null;
		lblEnvOPerationenableMentMap=null;
		exportFileDetailsBeans=null;
		entityExportFileDetailsMap=null;
		applicationIdDependentApplicationBeanMap = null;
		childAndParentEntityLinkMasterBeanMap=null;
		appTypeRootEntityMap = null;
		appTypeEntityNameTableNameListMap = null;
		appTypeEntityNameTableNameListDeleteMap =  null;
		appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap=null;//1.1
		System.out.println("LabelCache = null");
	}
	
	
	public static  Map<String,List<EntityLinkDetailMasterBean>> getchildAndParentEntityLinkMasterBeanMap() throws FrameWorkSystemException{
		Connection conn = null;
		Map<String,List<EntityLinkDetailMasterBean>>  appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap=null;
		try{
			if(appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap == null){
				conn = ResourceManager.getConnection();
				appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap=populateAppTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap();			}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return appTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap;			
	}
	
	
	public static Map<String, String> getAppTypeRootEntityMap() throws FrameWorkSystemException{
		Connection conn = null;
		try{
			if(appTypeRootEntityMap == null){
				conn = ResourceManager.getConnection();
				appTypeRootEntityMap = populateAppTypeRootEntityMap(conn);
			}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return appTypeRootEntityMap;			
		
	}
	
	
	private  static Map<String, String> populateAppTypeRootEntityMap(Connection conn) throws FrameWorkSystemException {
		//String sql="select entity_name, module_type from tb_ent_link_master where lower(parent_entity_name)='root'";
		String sql = Queries.GET_ROOT_ENTITY_FOR_APP_TYPE;		
		Map<String, String> appTypeRootEntityMap = new HashMap<String, String>(); 
		List<Map> entityNamesMapList = new ResourceManager().executePreparedStatement(conn,sql);		
		
		for(Map entityNameMap: entityNamesMapList){
			String entityName = (String)entityNameMap.get("ENTITY_NAME");
			String appType = (String)entityNameMap.get("MODULE_TYPE");
			appTypeRootEntityMap.put(appType, entityName);
		}
		
		return appTypeRootEntityMap ;
	}


	public static  Map<Integer, DependentApplication> getApplicationIdToEntityDependentApplicationBean() throws FrameWorkSystemException{
		Connection conn = null;
		try{
			if(applicationIdDependentApplicationBeanMap == null){
				conn = ResourceManager.getConnection();
				applicationIdDependentApplicationBeanMap = populateApplicationIdToEntityDependentApplicationBeanMap(conn);
			}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return applicationIdDependentApplicationBeanMap;
			
	}
	
	private static Map<Integer, DependentApplication> populateApplicationIdToEntityDependentApplicationBeanMap(Connection conn) throws FrameWorkSystemException {
		Map<Integer, DependentApplication> applicationIdToEntityDependentApplicationBeanMap = new HashMap<Integer, DependentApplication>();
		DependentApplication entityDependentApplicationBean = null;
		//select distinct(entity_name) from TB_ENT_SCHEMAOBJECT_METADATA
		String sql = Queries.GET_DEPENDENT_APPLICATION;		
		List<Map> entityNamesMapList = new ResourceManager().executePreparedStatement(conn,sql);		
		
		for(Map entityNameMap: entityNamesMapList){
			Integer applicationId = (Integer)entityNameMap.get("APPLICATION_ID");
			String applicationLabel = (String)entityNameMap.get("APPLICATION_LABEL");
			String skipUnlabeled = (String)entityNameMap.get("SKIP_UNLABELED");
			String appType = (String)entityNameMap.get("APP_TYPE");
			entityDependentApplicationBean = new DependentApplication(applicationId, applicationLabel, skipUnlabeled, appType);
			applicationIdToEntityDependentApplicationBeanMap.put(applicationId, entityDependentApplicationBean);
		}
		
		return applicationIdToEntityDependentApplicationBeanMap;
	}

	public static  Map<String,Boolean> getEnvironmentalEnablementMap()throws FrameWorkSystemException{
		Connection conn = null;
		try{
			if(lblEnvOPerationenableMentMap == null){
				conn = ResourceManager.getConnection();
				lblEnvOPerationenableMentMap = populateLabelEnvOPerationenableMentMap(conn);
			}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return lblEnvOPerationenableMentMap;
			
	}
	
	public static  Map<String,List<String>> getEntityExportFileDetailsMap(Connection conn)throws FrameWorkSystemException{
		List<String> entityList=null;
		try{
			if(entityExportFileDetailsMap == null){
				entityExportFileDetailsMap=new HashMap<String, List<String>>();
				List<ExportFileDetailsBean>  exportFileDetailsBeans=getExportFileDetailsBeanList(conn);
				Set<String> fileNameSet=new TreeSet<String>();
				for(ExportFileDetailsBean bean:exportFileDetailsBeans){
					fileNameSet.add(bean.getExportFileName());
				}
				for(String fileName:fileNameSet){
					entityList=new ArrayList<String>();
					for(ExportFileDetailsBean bean:exportFileDetailsBeans){
						if(fileName.equalsIgnoreCase(bean.getExportFileName()))
						entityList.add(bean.getEntityName());
					}	
					entityExportFileDetailsMap.put(fileName, entityList);
				}
			}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		return entityExportFileDetailsMap;
			
	}

	public static  List<ExportFileDetailsBean> getExportFileDetailsBeanList(Connection conn)  throws FrameWorkSystemException{
		exportFileDetailsBeans=null;
		try{
		if(exportFileDetailsBeans == null){
			exportFileDetailsBeans  =populateExportFileDetailsBean(conn);
		}
		}	
		catch(Exception e){
			e.printStackTrace();
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		return exportFileDetailsBeans;
	}


	public static Map<String, EntityActionMasterBean> getActionIdEntityActionMasterBeanMap() throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if(actionIdEntityActionMasterBeanMap == null){
			conn = ResourceManager.getConnection();
			actionIdEntityActionMasterBeanMap = populateActionIdEntityActionMasterBeanMap(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return actionIdEntityActionMasterBeanMap;		
	}
	
	

	public static Map<String, List<SchemaObjectMetaDataBean>> getEntityNameSchemaObjectMetaDataMap() throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if(entityNameSchemaObjectMetaDataBeanMap == null){
			conn = ResourceManager.getConnection();
			entityNameSchemaObjectMetaDataBeanMap = populateEntityNameSchemaObjectMetaDataMap(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return entityNameSchemaObjectMetaDataBeanMap;		
	}
	
	/*
	public static Map<String, ApplicationInfoBean> getAppNameAppInfoBeanMap() throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if(appNameAppInfoBeanMap == null){
			conn = ResourceManager.getConnection();
			appNameAppInfoBeanMap = populateAppNameDependentAppInfoBeanMap(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return appNameAppInfoBeanMap;
	}
	*/

	public static Map<String, List<EntityLinkMasterBean>> getAppTypeEntityLinkMasterBeanMap()  throws FrameWorkSystemException{
		Connection conn = null;
		appTypeEntityLinkMasterBeanMap=null;
		try{
		if(appTypeEntityLinkMasterBeanMap == null){
			conn = ResourceManager.getConnection();
			appTypeEntityLinkMasterBeanMap  =populateAppTypeEntityTree(conn);
		}
		}	
		catch(Exception e){
			e.printStackTrace();
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return appTypeEntityLinkMasterBeanMap;
	}

	public static Map<String, List<EntityMasterBean>> getEntityNameEntityMasterBeanMap()   throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if( entityNameEntityMasterBeanMap==null){
			conn = ResourceManager.getConnection();
			entityNameEntityMasterBeanMap = populateEntityTableInfoBeans(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return entityNameEntityMasterBeanMap;
	}

	public static Map<String, List<EntityColumnInfoBean>> getTableNameEntityColumnInfoBeanMap() throws FrameWorkSystemException {
		Connection conn = null;
		try{
		if(tableNameEntityColumnInfoBeanMap ==null){
			conn = ResourceManager.getConnection();
			tableNameEntityColumnInfoBeanMap = populateTableNameColumnInfoBeans(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return tableNameEntityColumnInfoBeanMap;
	}

	
	public static Map<String, List<EntityForeignKeyDetailMasterBean>> getConstraintNameEntityForeignKeyDetailsMasterBeanMap()   throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if(constraintNameEntityForeignKeyDetailsMasterBeanMap ==null){
			conn = ResourceManager.getConnection();
			constraintNameEntityForeignKeyDetailsMasterBeanMap = populateConstraintNameEntityForeignKeyDetailsMasterBeanMap(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return constraintNameEntityForeignKeyDetailsMasterBeanMap;
	}

	public static Map<String, List<EntityPrimaryKeyMasterBean>> getEntityNameEntityPrimaryKeyMasterBeanMap()   throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if(entityNameEntityPrimaryKeyMasterBeanMap ==null){
			conn = ResourceManager.getConnection();
			entityNameEntityPrimaryKeyMasterBeanMap = populateEntityPrimaryKeyInfoBeans(conn);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return entityNameEntityPrimaryKeyMasterBeanMap;
	}
	 
	public static Map<String, List<EntityDetailMasterBean>> getEntityNameEntityDetailMasterBeanMap()   throws FrameWorkSystemException{
		Connection conn = null;
		try{
		if(entityNameEntityDetailMasterBeanMap ==null){
			conn = ResourceManager.getConnection();
			entityNameEntityDetailMasterBeanMap = populateParentChildInfoBeans(conn);
			System.out.println(entityNameEntityDetailMasterBeanMap);
		}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		finally{DBResourceUtil.closeResource(conn);}
		return entityNameEntityDetailMasterBeanMap;
	}

	private static List<ExportFileDetailsBean> populateExportFileDetailsBean(Connection conn)throws FrameWorkSystemException  {
		// here disabled means enabled and enabled means disabled
		List<ExportFileDetailsBean> exportFileDetailsBeans=null;
		String sql="";
		ExportFileDetailsBean bean=null;
		try{
			sql=Queries.GET_EXPORT_FILE_AND_ENTITY_DETAILS;
			List<Map> listMap= new ResourceManager().executePreparedStatement(conn,sql);
			exportFileDetailsBeans=new ArrayList<ExportFileDetailsBean>();
			for(Map map:listMap){
				bean=new ExportFileDetailsBean();
				bean.setExportFileName((String)map.get("FILE_NAME"));
				bean.setExportFileId((Integer)map.get("EXPORT_FILE_ID"));
				bean.setEntityName((String)map.get("ENTITY_NAME"));
				exportFileDetailsBeans.add(bean);
			}
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
		return exportFileDetailsBeans;
	}
	private static Map<Integer, String> populateAPTExportFileDetailsMap(Connection conn)throws FrameWorkSystemException  {
		// here disabled means enabled and enabled means disabled
		HashMap<Integer, String> exportFileMap=null;
		String sql="";
		try{
			sql=Queries.GET_EXPORT_FILE_DETAILS;
			List<Map> listMap= new ResourceManager().executePreparedStatement(conn,sql);
			exportFileMap=new HashMap<Integer, String>();
			for(Map map:listMap){
				exportFileMap.put((Integer)map.get("EXPORT_FILE_ID"),(String)map.get("FILE_NAME"));
			}
			
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
			return exportFileMap;
			
	}
	private static Map<String, Boolean> populateLabelEnvOPerationenableMentMap(Connection conn)throws FrameWorkSystemException  {
		// here disabled means enabled and enabled means disabled
		HashMap<String,Boolean> envEnablemap=null;
		String sql="";
		try{
			sql=Queries.GET_LABEL_ENV_TYPE_DETAIL;
			List<Map> listMap= new ResourceManager().executePreparedStatement(conn,sql);
			envEnablemap=new HashMap<String, Boolean>();
			for(Map map:listMap){
				envEnablemap.put(map.get("ENVIRONMENTTYPE").toString()+map.get("OPERATIONTYPE").toString()+map.get("FIELDNAME").toString(),!"Y".equalsIgnoreCase(map.get("ISENABLED").toString()));
			}
			
		}
		catch(Exception e){
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
		}
			return envEnablemap;
			
	}
	public static Map<String, List<EntityLinkDetailMasterBean>> getEntityNameEntityLinkDetailsMasterBeanMap()   throws FrameWorkSystemException{
		if( entityNameEntityLinkDetailsMasterBeanMap==null){
			Connection conn = null;
			 
			try {
				conn = ResourceManager.getConnection();
				entityNameEntityLinkDetailsMasterBeanMap = populateEntityRelationshipInfoBeans(conn);
			} catch (Exception e) {
				mLog.fatal(e.getMessage(), e);
				throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
			} finally {
				DBResourceUtil.closeResource(conn);
			}

		}
		return entityNameEntityLinkDetailsMasterBeanMap;
	}
	
	public static Map<String, Map<String, List<String>>> getTableNamesInInsertOrder() throws FrameWorkSystemException{
		if( appTypeEntityNameTableNameListMap==null){
			Connection conn = null;
			
			try {
				conn = ResourceManager.getConnection();
				appTypeEntityNameTableNameListMap = populateTableNamesInInsertOrder(conn);
			} catch (Exception e) {
				mLog.fatal(e.getMessage(), e);
				throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
			}
			finally{
				DBResourceUtil.closeResource(conn);
			}

		}
		return appTypeEntityNameTableNameListMap;
	}	

	
	public static Map<String, Map<String, List<String>>> getTableNamesInDeleteOrder() throws FrameWorkSystemException{
		if( appTypeEntityNameTableNameListDeleteMap==null){
			Connection conn = null;
			
			try {
				conn = ResourceManager.getConnection();
				appTypeEntityNameTableNameListDeleteMap = populateTableNamesInDeleteOrder(conn);
			} catch (Exception e) {
				mLog.fatal(e.getMessage(), e);
				throw new FrameWorkSystemException(LabelCache.class, e.getMessage(), e);
			}
			finally{
				DBResourceUtil.closeResource(conn);
			}

		}
		return appTypeEntityNameTableNameListDeleteMap;
	}	

	private static Map<String, EntityActionMasterBean> populateActionIdEntityActionMasterBeanMap(Connection conn) throws FrameWorkSystemException {
		Map<String, EntityActionMasterBean> actionIdEntityActionMasterBeanMap = new HashMap<String, EntityActionMasterBean>();
		List<String> actionIdList = getActionIds(conn);
		for(String actionId: actionIdList){
			EntityActionMasterBean bean = getEntityActionMasterBean(actionId, conn);
			actionIdEntityActionMasterBeanMap.put(actionId, bean);
		}
		return actionIdEntityActionMasterBeanMap;
	}

	private static EntityActionMasterBean getEntityActionMasterBean(String actionId, Connection conn) throws FrameWorkSystemException {
		EntityActionMasterBean bean = new EntityActionMasterBean();
		String sql = Queries.GET_ENTITY_ACTION_MASTER_BY_ACTION_ID;
		List<Map> resultSetMap = new ResourceManager().executePreparedStatement(conn, sql, actionId);
		for(Map record: resultSetMap){
			String actionName = (String)record.get("ACTION_NAME");
			String actionValue = (String) record.get("ACTION_VALUE");
			String defaultFlag = (String) record.get("DEFAULT_VALUE");
			
			if(defaultFlag.equalsIgnoreCase("Y")) 
				bean.setDefaultActionValue(actionValue)
					.setActionId(actionId)
					.setActionName(actionName);
			else 
				bean.addActionValue(actionValue)
					.setActionId(actionId)
					.setActionName(actionName);
		}
		return bean;
	}

	private static List<String> getActionIds(Connection conn) throws FrameWorkSystemException {
		List<String> actionIds = new ArrayList<String>();
		String sql = Queries.GET_ALL_ACTION_ID;
		List<Map> actionIdList = new ResourceManager().executePreparedStatement(conn, sql);
		for(Map actionId: actionIdList){
			actionIds.add((String)actionId.get("ACTION_ID"));
		}
		return actionIds;
	}

	private static Map<String, List<SchemaObjectMetaDataBean>> populateEntityNameSchemaObjectMetaDataMap(Connection conn) throws FrameWorkSystemException {
		entityNameSchemaObjectMetaDataBeanMap = new HashMap<String, List<SchemaObjectMetaDataBean>> ();
		//select distinct(entity_name) from TB_ENT_SCHEMAOBJECT_METADATA
		String sql = Queries.GET_DISTINCT_ENTITY_NAMES_FROM_SCHEMAOBJECT_METADATA;		
		List<Map> entityNamesMapList=new ResourceManager().executePreparedStatement(conn,sql);		
		for(Map entityNameMap: entityNamesMapList){
			entityNameSchemaObjectMetaDataBeanMap.put((String)entityNameMap.get("ENTITY_NAME"), null);
		}
		for(String distinctEntityName: entityNameSchemaObjectMetaDataBeanMap.keySet()){
			//select APP_TYPE, SCHEMAOBJECT_TYPE, NAME, WHERE_CLAUSE, TABLE_NAME FROM TB_ENT_SCHEMAOBJECT_METADATA WHERE ENTITY_NAME = ?
			sql = Queries.GET_SCHEMAONJECT_METADATA_FROM_SCHEMAOBJECT_METADATA;
			List<SchemaObjectMetaDataBean> listSchemaObjectMetaDataBean = new ArrayList<SchemaObjectMetaDataBean>();
			List<Map> schemaObjectsMetaDataMapList=new ResourceManager().executePreparedStatement(conn,sql, distinctEntityName);
			for(Map m:schemaObjectsMetaDataMapList){
				SchemaObjectMetaDataBean somdb = new SchemaObjectMetaDataBean();
				somdb.setEntityName(distinctEntityName);
				somdb.setAppType((String)m.get("APP_TYPE"));
				somdb.setName((String)m.get("NAME"));
				somdb.setSchemaObjectType((String)m.get("SCHEMAOBJECT_TYPE"));
				somdb.setTableName((String)m.get("TABLE_NAME"));
				somdb.setWhereClause((String)m.get("WHERE_CLAUSE"));
				if(APTConstant.SEQUENCEOBJECT.equalsIgnoreCase(somdb.getSchemaObjectType()) || APTConstant.VIEWOBJECT.equalsIgnoreCase(somdb.getSchemaObjectType()))
				listSchemaObjectMetaDataBean.add(somdb);
			}	
			entityNameSchemaObjectMetaDataBeanMap.put(distinctEntityName, listSchemaObjectMetaDataBean);
		}
		return entityNameSchemaObjectMetaDataBeanMap;
	}

	/*
	private static Map<String, ApplicationInfoBean> populateAppNameDependentAppInfoBeanMap(Connection conn) throws FrameWorkSystemException{
		List<String> appNames = getAppTypes(conn);
		appNameAppInfoBeanMap =  new HashMap<String, ApplicationInfoBean>() ;
		for(String appName: appNames){
			ApplicationInfoBean a = getAppInfoBean(conn, appName);
			appNameAppInfoBeanMap.put(appName, a);
		}
		return appNameAppInfoBeanMap;
	}
	*/
	private static List<String> getAppTypes(Connection conn) throws FrameWorkSystemException{		
		List<String> listAppType=new ArrayList<String>();
		listAppType.add(APTConstant.PROPERTYCONSOLE);
		listAppType.add(APTConstant.SYSTEMSETUP);
		listAppType.add(APTConstant.COMMONAPPLICATION);
		listAppType.add(APTConstant.APPLICATION);
		listAppType.add(APTConstant.WORKSPACE);
		listAppType.add("Txn_Entity");
		listAppType.add("Ref_Entity");
		/*
		List<Map> listAppTypeMap= new ArrayList<Map>();
		String sql=Queries.GET_MODULE_TYPE;
		listAppTypeMap=new ResourceManager().executePreparedStatement(conn,sql);
		for(Map m:listAppTypeMap){
			Collection <String> c=m.values();
			for(String s:c){
				listAppType.add(s);
			}
		}*/
		return listAppType;
	}

/*	private static ApplicationInfoBean getAppInfoBean(Connection pConn,String pAppType) throws FrameWorkSystemException {		
		List<String> listAppType=new ArrayList<String>();
		List<Map> listAppInfoMap= new ArrayList<Map>();
		List<Map> listModuleMap= new ArrayList<Map>();
		ApplicationInfoBean appInfoObj=new ApplicationInfoBean();
		String sql=Queries.GET_HAS_DEPENDENT_MODULES;
		ArrayList<DependentApplicationInfoBean> dependentApplications = new ArrayList<DependentApplicationInfoBean>();
		listAppInfoMap=new ResourceManager().executePreparedStatement(pConn,sql,pAppType);
		for(Map m:listAppInfoMap){				
			appInfoObj.setHasDependentApplication((String)m.get("HAS_DEPENDENT_MODULES"));
			appInfoObj.setAppType(pAppType);							
			if(("Y").equalsIgnoreCase(appInfoObj.getHasDependentApplication()))	{				
				sql=Queries.GET_DEPENDENT_MODULES;
				listModuleMap=new ResourceManager().executePreparedStatement(pConn,sql,pAppType);					
				for(Map map:listModuleMap){
					DependentApplicationInfoBean d = new DependentApplicationInfoBean();
					d.setDependentAppType((String)map.get("APP_TYPE"));					
					d.setDepenentSequence((Integer)map.get("DEPENDENT_SEQUENCE"));
					dependentApplications.add(d);
				}					
			}				
		appInfoObj.setDependentApplications(dependentApplications);
		}
		return appInfoObj;
	}
*/	
	private static Map<String, List<EntityLinkMasterBean>> populateAppTypeEntityTree(Connection pConn) throws FrameWorkSystemException {
		appTypeEntityLinkMasterBeanMap = new HashMap<String, List<EntityLinkMasterBean>> ();
		List<String> appsList = getAppTypes(pConn) ;
		for(String pAppType: appsList){
		String sql = Queries.GET_APPTYPE_ENTITY_TREE;		
		//SELECT ENTITY_NAME, PARENT_ENTITY_NAME, ENTITY_LEVEL, ENTITY_LEVEL_SEQ, HAS_CHILD, ENTITY_CAPTION 
		//FROM TB_ENTITY_TREE WHERE MODULE_TYPE=? AND PARENT_ENTITY_NAME='Root'
		List<Map> listEntityTreeInfoMap=new ResourceManager().executePreparedStatement(pConn,sql,pAppType);
		
		List<EntityLinkMasterBean> entityLinkMasterBeanList = new ArrayList<EntityLinkMasterBean>();
		for(Map m:listEntityTreeInfoMap){
			EntityLinkMasterBean etib=new EntityLinkMasterBean();
			String entityName = (String)m.get("ENTITY_NAME");
			String parentEntity = (String)m.get("PARENT_ENTITY_NAME");
			Integer entityLevel = (Integer)m.get("ENTITY_LEVEL");
			Integer entitylevelSeq = (Integer)m.get("ENTITY_LEVEL_SEQ");
			String entityCaption = (String)m.get("ENTITY_CAPTION");
			String hasChild = (String)m.get("HAS_CHILD");
			Integer exportFileId =(Integer)m.get("EXPORT_FILE_ID");
			etib.setAppType(pAppType);
			etib.setEntityCaption(entityCaption);
			etib.setEntityName(entityName);
			etib.setEntityLevel(entityLevel);
			etib.setEntityLevelSeq(entitylevelSeq);
			etib.setParentEntityName(parentEntity);			
			List<EntityLinkMasterBean> entityTreeInfoBean= new ArrayList<EntityLinkMasterBean>();
			etib.setHasChild(hasChild);
			if("Y".equalsIgnoreCase(hasChild)){
				entityTreeInfoBean=	getChildModuleEntityTree(pConn,pAppType,entityName);
			}
			etib.setEntityTreeInfoBean(entityTreeInfoBean);
			etib.setExportFileId(exportFileId);
			entityLinkMasterBeanList.add(etib);
		}
		appTypeEntityLinkMasterBeanMap.put(pAppType, entityLinkMasterBeanList);
		}
		return appTypeEntityLinkMasterBeanMap;
	}

	private static List<EntityLinkMasterBean> getChildModuleEntityTree(Connection pConn,String pAppType, String parentEntityName) throws FrameWorkSystemException {
		String sql = Queries.GET_APPTYPE_CHILD_ENTITY_TREE;
		//moduleNameEntityTreeInfoBeanMap = new HashMap<String, List<EntityTreeInfoBean>> ();
		//SELECT ENTITY_NAME, PARENT_ENTITY_NAME, ENTITY_LEVEL, ENTITY_LEVEL_SEQ, HAS_CHILD, ENTITY_CAPTION 
		//FROM TB_ENTITY_TREE WHERE MODULE_TYPE=? AND PARENT_ENTITY_NAME='?'
		List<Object> list=new ArrayList<Object>();
		list.add(pAppType);
		list.add(parentEntityName);
		List<Map> listEntityTreeInfoMap=new ResourceManager().executePreparedStatement(pConn,sql,list);
		//Map<String, List<EntityTreeInfoBean>> entityTreeInfoBeanMap = new HashMap<String, List<EntityTreeInfoBean>>();
		List<EntityLinkMasterBean> etibList=new ArrayList<EntityLinkMasterBean>();
		for(Map m:listEntityTreeInfoMap){
			EntityLinkMasterBean etib=new EntityLinkMasterBean();
			String entityName = (String)m.get("ENTITY_NAME");
			String parentEntity = (String)m.get("PARENT_ENTITY_NAME");
			Integer entityLevel = (Integer)m.get("ENTITY_LEVEL");
			Integer entitylevelSeq = (Integer)m.get("ENTITY_LEVEL_SEQ");
			String entityCaption = (String)m.get("ENTITY_CAPTION");
			String hasChild = (String)m.get("HAS_CHILD");
			etib.setEntityCaption(entityCaption);
			etib.setEntityName(entityName);
			etib.setEntityLevel(entityLevel);
			etib.setEntityLevelSeq(entitylevelSeq);
			etib.setParentEntityName(parentEntity);
			etib.setAppType(pAppType);
			List<EntityLinkMasterBean> entityTreeInfoBean= new ArrayList<EntityLinkMasterBean>();
			etib.setHasChild(hasChild);
			if("Y".equalsIgnoreCase(hasChild)){
				entityTreeInfoBean=	getChildModuleEntityTree(pConn,pAppType,entityName);
			}
			etib.setEntityTreeInfoBean(entityTreeInfoBean);
			etibList.add(etib);
		}
		return etibList;
	}

	
	private static Map<String, List<EntityMasterBean>> populateEntityTableInfoBeans(Connection conn) throws FrameWorkSystemException{
		entityNameEntityMasterBeanMap =  new HashMap<String, List<EntityMasterBean>> ();
		List<String> entityList = getEntityNamesFromEntityTableInfo(conn);
		for(String entityName: entityList){
			List<EntityMasterBean> entityTableInfoBeanList =getEntityMasterBean(conn, entityName);
			entityNameEntityMasterBeanMap.put(entityName, entityTableInfoBeanList);
		}
		return entityNameEntityMasterBeanMap; 
	}
	
	private static List<String> getEntityNamesFromEntityTableInfo(Connection conn) throws FrameWorkSystemException{
		String sql = Queries.GET_ENTITYNAMES_FROM_ENTITY_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql);
		List<String> entityNamesList = new ArrayList<String>();
		for(Map m:list1){
			entityNamesList.add((String)m.get("ENTITY_NAME"));
		}
		return entityNamesList;
	}
	
	private static List<EntityMasterBean> getEntityMasterBean(Connection conn, String entityName)  throws FrameWorkSystemException{
		//System.err.println("entityName" + entityName);
		//SELECT TABLE_NAME, TABLE_CAPTION, IS_PRIMARY, HISTORY_TABLE_NAME, LABEL_TABLE_NAME FROM TB_ENTITY_INFO WHERE ENTITY_NAME=?
		String sql = Queries.GET_ENTITY_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql,entityName);
		List<EntityMasterBean> listTableInfoBean = new ArrayList<EntityMasterBean>();				
		for(Map map:list1){
			EntityMasterBean tib=new EntityMasterBean();
			String tableName = (String)map.get("TABLE_NAME");
			String tableCaption= (String)map.get("TABLE_CAPTION");
			String isPrimary= (String)map.get("IS_PRIMARY");
			String historyTableName= (String)map.get("HISTORY_TABLE_NAME");
			String auditColumnName = (String)map.get("AUDIT_COLUMN_NAME");
			String actionColumnName = (String)map.get("ACTION_COLUMN_NAME");
			
			tib.setTableName(tableName);
			tib.setTableCaption(tableCaption);
			tib.setIsPrimary(isPrimary);
			tib.setHistoryTableName(historyTableName);
			tib.setAuditColumnName(auditColumnName);
			tib.setActionColumnName(actionColumnName);
			listTableInfoBean.add(tib);
			
		}		
		return listTableInfoBean;
	}
//Map<String, List<ColumnInfoBean>> tableNameColumnInfoBeanMap
	private static Map<String, List<EntityColumnInfoBean>> populateTableNameColumnInfoBeans(Connection conn) throws FrameWorkSystemException{
		tableNameEntityColumnInfoBeanMap =  new HashMap<String, List<EntityColumnInfoBean>>();
		List<String> tableList = getTableNamesFromEntityColumnInfo(conn);
		for(String tableName: tableList){
			List<EntityColumnInfoBean> columnInfoBeanList =getColumnInfo(conn, tableName);
		//	Collections.sort(columnInfoBeanList, new ColumnNameSorter());
			tableNameEntityColumnInfoBeanMap.put(tableName, columnInfoBeanList);
		}
		return tableNameEntityColumnInfoBeanMap;
	}
	
/*	public static class ColumnNameSorter implements Comparator<ColumnInfoBean>{
        public int compare(ColumnInfoBean one, ColumnInfoBean another){
            return one.getColumnName().compareTo(another.getColumnName());
        }


	}*/
	
	private static List<String> getTableNamesFromEntityColumnInfo(Connection conn) throws FrameWorkSystemException{
		String sql = Queries.GET_TABLENAMES_FROM_COLUMN_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql);
		List<String> tableNamesList = new ArrayList<String>();
		for(Map m:list1){
			tableNamesList.add((String)m.get("TABLE_NAME"));
		}
		return tableNamesList;
	}
	
	private static  List<EntityColumnInfoBean> getColumnInfo(Connection conn, String tableName)  throws FrameWorkSystemException{
		List<EntityColumnInfoBean> columnInfoBeanList = new ArrayList<EntityColumnInfoBean>();		
		String sql = Queries.GET_ENTITY_TABLE_COLUMN_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql,tableName);
		for(Map map:list1){
			EntityColumnInfoBean cib=new EntityColumnInfoBean();
			//COLUMN_NAME, COLUMN_CAPTION, COLUMN_SEQUENCE, IS_LISTING_COLUMN, DATA_TYPE, IS_TREE_LABEL_COLUMN, IS_HASHING_COLUMN
			if(map.get("COLUMN_NAME")!=null){
			 String columnName= (String)map.get("COLUMN_NAME");
			 String columnCaption= (String)map.get("COLUMN_CAPTION");
			 Integer columnSequence= (Integer)map.get("COLUMN_SEQUENCE");
			 String isListingColumn= (String)map.get("IS_LISTING_COLUMN");
			 String dataType= (String)map.get("DATA_TYPE");
			 String isLabelTreeColumn= (String)map.get("IS_TREE_LABEL_COLUMN");
			 String isHashingColumn= (String)map.get("IS_HASHING_COLUMN");	
			 cib.setColumnCaption(columnCaption);
			 cib.setColumnName(columnName);
			 cib.setColumnSeq(columnSequence);
			 cib.setDataType(dataType);
			 cib.setHashingColumn(isHashingColumn);
			 cib.setListColumn(isListingColumn);			 
			 cib.setTreeLabelColumn(isLabelTreeColumn);
			 cib.setTableName(tableName);			 
			 columnInfoBeanList.add(cib);
			}
		}		
		return columnInfoBeanList;
	}

	//Map<String, List<EntityPrimaryKeyInfoBean>> entityNameEntityPrimaryKeyInfoBeanMap
	private static Map<String, List<EntityPrimaryKeyMasterBean>> populateEntityPrimaryKeyInfoBeans(Connection conn) throws FrameWorkSystemException{
		entityNameEntityPrimaryKeyMasterBeanMap =  new HashMap<String, List<EntityPrimaryKeyMasterBean>>();
		List<String> entityNames = getEntityNamesFromEntityPrimaryKeyInfo(conn);
		for(String entityName: entityNames){
			//System.out.println("LabelCache.populateEntityPrimaryKeyInfoBeans()"+entityName);
			List<EntityPrimaryKeyMasterBean> primaryKeyInfoBeanList =getPrimaryKeyInfo(conn, entityName);
			entityNameEntityPrimaryKeyMasterBeanMap.put(entityName, primaryKeyInfoBeanList);
		}
		return entityNameEntityPrimaryKeyMasterBeanMap;
	}
	
	private static List<String> getEntityNamesFromEntityPrimaryKeyInfo(Connection conn) throws FrameWorkSystemException{
		String sql = Queries.GET_ENTITYNAMES_FROM_ENTITY_PRIMARY_KEY_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql);
		List<String> entityNamesList = new ArrayList<String>();
		for(Map m:list1){
			entityNamesList.add((String)m.get("ENTITY_NAME"));
		}
		return entityNamesList;
	}
	
	//SELECT COLUMN_NAME, COLUMN_SEQUENCE,COLUMN_DATA_TYPE, ENTITY_NAME,TABLE_NAME FROM TB_ENT_PK_MASTER WHERE ENTITY_NAME=?
	private static List<EntityPrimaryKeyMasterBean> getPrimaryKeyInfo(Connection conn, String entityName)  throws FrameWorkSystemException{
		List<EntityPrimaryKeyMasterBean> listPKInfoBean = new ArrayList<EntityPrimaryKeyMasterBean>();	
		String sql = Queries.GET_ENTITY_PRIMARY_KEY_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql,entityName);
		for(Map map:list1){
			EntityPrimaryKeyMasterBean epkb= new EntityPrimaryKeyMasterBean();
			epkb.setColumnDataType((String)map.get("COLUMN_DATA_TYPE"));
			epkb.setColumnName((String)map.get("COLUMN_NAME"));
			epkb.setColumnSequence(Integer.valueOf(String.valueOf(map.get("COLUMN_SEQUENCE"))));
			epkb.setEntityName((String)map.get("ENTITY_NAME"));
			epkb.setTableName((String)map.get("TABLE_NAME"));
			listPKInfoBean.add(epkb);
		}				
		return listPKInfoBean;
	}

	
	//Map<String, List<EntityDetailMasterBean>> entityNameParentChildTableInfoMap
	private static Map<String, List<EntityDetailMasterBean>> populateParentChildInfoBeans(Connection conn) throws FrameWorkSystemException{
		entityNameEntityDetailMasterBeanMap =  new HashMap<String, List<EntityDetailMasterBean>>();
		List<String> entityNames = getEntityNamesFromParentChildTableInfo(conn);
		for(String entityName: entityNames){
			List<EntityDetailMasterBean> primaryKeyInfoBeanList =getEntityDetailMaster(conn, entityName);
			entityNameEntityDetailMasterBeanMap.put(entityName, primaryKeyInfoBeanList);
		}
		return entityNameEntityDetailMasterBeanMap; 
	}
	
	private static  List<String> getEntityNamesFromParentChildTableInfo(Connection conn) throws FrameWorkSystemException{
		String sql = Queries.GET_ENTITYNAMES_FROM_PARENT_CHILD_INFO;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql);
		List<String> entityNamesList = new ArrayList<String>();
		for(Map m:list1){
			entityNamesList.add((String)m.get("ENTITY_NAME"));
		}
		return entityNamesList;
	}
	
	//SELECT COLUMN_NAME, COLUMN_SEQUENCE,COLUMN_DATA_TYPE, ENTITY_NAME,TABLE_NAME FROM TB_ENTITY_PRIMARYKEY_INFO WHERE ENTITY_NAME=?
	private static List<EntityDetailMasterBean> getEntityDetailMaster(Connection conn, String entityName) throws FrameWorkSystemException{
		String sql = Queries.GET_TB_ENT_DETAIL_MASTER;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql,entityName);
		//entityInfoBean.setTableInfo(tableName);
		List<EntityDetailMasterBean> listTableInfoBean = new ArrayList<EntityDetailMasterBean>();
		for(Map map:list1){
			EntityDetailMasterBean pcei=new EntityDetailMasterBean();
			String lEntityName= entityName;
			String lTableName= (String)map.get("TABLE_NAME");
			String lTableColumnName= (String)map.get("TABLE_COLUMN_NAME");
			String lChildTablename= (String)map.get("CHILD_TABLE_NAME");
			String lChildTableColumnName= (String)map.get("CHILD_TBL_COL_NAME");
			String lChildFixedValue= (String)map.get("CHILD_FIXED_VALUE");
			int groupNumber = (Integer)map.get("GROUP_NUMBER");
			
			pcei.setColumnName(lTableColumnName);
			pcei.setEntityName(lEntityName);
			pcei.setTableName(lTableName);
			pcei.setChildTableName(lChildTablename);
			pcei.setChildFixedValue(lChildFixedValue);
			pcei.setChildColumnName(lChildTableColumnName);
			pcei.setGroupNumber(groupNumber);
			listTableInfoBean.add(pcei);
		}		
		return listTableInfoBean;
	}

	
	
	static String getPrimaryTable(String entityName, String tableType)  throws FrameWorkSystemException{
//		logger.debug(String.format("entity Name: %s , type : %s", entityName, Type));
		 Map<String, List<EntityMasterBean>> entityNameEntityTableInfoBeanMap = getEntityNameEntityMasterBeanMap();
//		 logger.debug(entityNameEntityTableInfoBeanMap.size());
		 if(entityNameEntityTableInfoBeanMap.containsKey(entityName)){
			 List<EntityMasterBean> list  = entityNameEntityTableInfoBeanMap.get(entityName);
//			 logger.debug(list.size());
			 for(EntityMasterBean  etib: list){
//				 logger.debug(etib);
				 if(etib.getIsPrimary().equalsIgnoreCase("Y")){
					 if(tableType.equalsIgnoreCase(WFMaintConstants.MASTER_TYPE)){
						 return etib.getTableName();
					 }
					 if(tableType.equalsIgnoreCase(WFMaintConstants.HISTORY_TYPE)){
						 return etib.getHistoryTableName();						 
					 }				 
				 }
			 }
		 }
		 return null;
	}
	
	
	//SELECT COLUMN_NAME, COLUMN_SEQUENCE,COLUMN_DATA_TYPE, ENTITY_NAME,TABLE_NAME FROM TB_ENTITY_PRIMARYKEY_INFO WHERE ENTITY_NAME=?
		public static Map<String, Map<String, List<String>>> populateTableNamesInInsertOrder(Connection conn) throws FrameWorkSystemException{
			Map<String, List<EntityLinkMasterBean>> appTypeEntityLinkMasterBeanMap=getAppTypeEntityLinkMasterBeanMap();
			Map<String, Map<String, List<String>>> appTypeEntityNameTableNameListMap = new HashMap<String, Map<String,List<String>>>();
			Set<String> apps = appTypeEntityLinkMasterBeanMap.keySet();
			for(String appType:apps){
				List<EntityLinkMasterBean> listEntityLinkMasterBeans= appTypeEntityLinkMasterBeanMap.get(appType);
				for(EntityLinkMasterBean entityLinkMasterBean:listEntityLinkMasterBeans){
					Map<String, List<String>> entityNameToTableNameMap = new HashMap<String, List<String>>();
					List<String> tableNameList = new ArrayList<String>();
					Set<String> tableNameSet = new LinkedHashSet<String>();
					String entityName=entityLinkMasterBean.getEntityName();
					String parentTableName = LabelCache.getPrimaryTable(entityName, WFMaintConstants.MASTER_TYPE);
					tableNameSet.add(parentTableName);
					//tableNameList.add(parentTableName);
					//select CHILD_TABLE_NAME from TB_ENT_DETAIL_MASTER where entity_name=? order by GROUP_NUMBER
					String sql = Queries.GET_CHILD_TABLES_INSERT_ORDER;
					List<Map> recordSet = new ResourceManager().executePreparedStatement(conn, sql, entityName);
					for(Map record: recordSet){
						String childTableName = (String) record.get("CHILD_TABLE_NAME");						
						//tableNameList.add(childTableName);
						tableNameSet.add(childTableName);
					}
					tableNameList.addAll(tableNameSet);
					entityNameToTableNameMap.put(entityName, tableNameList);
					if(appTypeEntityNameTableNameListMap.containsKey(appType)){
						appTypeEntityNameTableNameListMap.get(appType).put(entityName, tableNameList);	
					}
					else {
						appTypeEntityNameTableNameListMap.put(appType, entityNameToTableNameMap);
					}
					
				}
			}
			return appTypeEntityNameTableNameListMap;
		}	
		
		public static Map<String, Map<String, List<String>>> populateTableNamesInDeleteOrder(Connection conn) throws FrameWorkSystemException{
			Map<String, List<EntityLinkMasterBean>> appTypeEntityLinkMasterBeanMap=getAppTypeEntityLinkMasterBeanMap();
			Map<String, Map<String, List<String>>> appTypeEntityNameTableNameListMap = new HashMap<String, Map<String,List<String>>>();
			Set<String> apps = appTypeEntityLinkMasterBeanMap.keySet();
			for(String appType:apps){
				List<EntityLinkMasterBean> listEntityLinkMasterBeans= appTypeEntityLinkMasterBeanMap.get(appType);
				for(EntityLinkMasterBean entityLinkMasterBean:listEntityLinkMasterBeans){
					Map<String, List<String>> entityNameToTableNameMap = new HashMap<String, List<String>>();
					List<String> tableNameList = new ArrayList<String>();
					Set<String> tableNameSet = new LinkedHashSet<String>();
					String entityName=entityLinkMasterBean.getEntityName();
					String parentTableName = LabelCache.getPrimaryTable(entityName, WFMaintConstants.MASTER_TYPE);
					//tableNameList.add(parentTableName);
					//select CHILD_TABLE_NAME from TB_ENT_DETAIL_MASTER where entity_name=? order by GROUP_NUMBER
					String sql = Queries.GET_CHILD_TABLES_DELETE_ORDER;
					List<Map> recordSet = new ResourceManager().executePreparedStatement(conn, sql, entityName);
					for(Map record: recordSet){
						String childTableName = (String) record.get("CHILD_TABLE_NAME");						
						//tableNameList.add(childTableName);
						tableNameSet.add(childTableName);
					}
					tableNameSet.add(parentTableName);
					tableNameList.addAll(tableNameSet);
					entityNameToTableNameMap.put(entityName, tableNameList);
					if(appTypeEntityNameTableNameListMap.containsKey(appType)){
						appTypeEntityNameTableNameListMap.get(appType).put(entityName, tableNameList);	
					}
					else {
						appTypeEntityNameTableNameListMap.put(appType, entityNameToTableNameMap);
					}
					
				}
			}
			return appTypeEntityNameTableNameListMap;
		}	

	//Map<String, List<EntityRelationshipInfoBean>> entityNameEntityRelationshipInfoBeanMap
	
	private static Map<String, List<EntityLinkDetailMasterBean>> populateEntityRelationshipInfoBeans(Connection conn) throws FrameWorkSystemException{
		entityNameEntityLinkDetailsMasterBeanMap =  new HashMap<String, List<EntityLinkDetailMasterBean>>();
		List<String> entityNames = getEntityNamesFromTableMapping(conn);
		for(String entityName: entityNames){
			List<EntityLinkDetailMasterBean> entityRelationshipInfoBeanList = getEntityRelationshipInfoBeans(conn, entityName);
			entityNameEntityLinkDetailsMasterBeanMap.put(entityName, entityRelationshipInfoBeanList);
		}
		return entityNameEntityLinkDetailsMasterBeanMap;
	}
	
	private static List<String> getEntityNamesFromTableMapping(Connection conn) throws FrameWorkSystemException{
		String sql = Queries.GET_ENTITYNAMES_FROM_TABLE_MAPPING;
		List<Map>  list1 = new ResourceManager().executePreparedStatement(conn,sql);
		List<String> entityNamesList = new ArrayList<String>();
		for(Map m:list1){
			entityNamesList.add((String)m.get("ENTITY_NAME"));
		}
		return entityNamesList;
	}
	
	
	private static List<EntityLinkDetailMasterBean> getEntityRelationshipInfoBeans(Connection conn, String entityName) throws FrameWorkSystemException{		
		String sql = Queries.GET_PARENT_CHILD_ENTITY_INFO;
		List<Map> listEntityTreeInfoMap=new ResourceManager().executePreparedStatement(conn,sql,entityName);
		List<EntityLinkDetailMasterBean> list = new ArrayList<EntityLinkDetailMasterBean>();		
		for(Map m:listEntityTreeInfoMap){
			EntityLinkDetailMasterBean pcei = new EntityLinkDetailMasterBean();
			entityName = (String)m.get("ENTITY_NAME");
			String entityTableName = (String)m.get("ENT_TABLE_NAME");
			String entityTableColumnName = (String)m.get("ENT_TABLE_COLUMN_NAME");
			Integer tableSequence = (Integer)(m.get("TABLE_SEQUENCE")!=null?m.get("TABLE_SEQUENCE"):0);
			String parentEntity = (String)m.get("PARENT_ENTITY_NAME");
			String parentEntityTableName = (String)m.get("PARENT_ENT_TABLE_NAME");
			String parentEntityTableColumnName = (String)m.get("PARENT_ENT_TBL_COL_NAME");
			String fixedValue = (String)(m.get("FIXED_VALUE")!=null?m.get("FIXED_VALUE"):"");
			String  relationShip=(String)(m.get("RELATIONSHIP")!=null?m.get("RELATIONSHIP"):"");
			
			pcei.setEntityName(entityName);
			pcei.setEntityTableName(entityTableName);
			pcei.setEntityTableColumnName(entityTableColumnName);
			pcei.setTableSequence(tableSequence);
			pcei.setParentEntityName(parentEntity);
			pcei.setParentTableColumnName(parentEntityTableColumnName);
			pcei.setParentTableName(parentEntityTableName);
			pcei.setEntityColumnFixedValue(fixedValue);
			pcei.setRelationShip(relationShip);
			
			list.add(pcei);
		}
		return list;
	}

	private static Map<String, List<EntityForeignKeyDetailMasterBean>> populateConstraintNameEntityForeignKeyDetailsMasterBeanMap(Connection conn) throws FrameWorkSystemException {
		constraintNameEntityForeignKeyDetailsMasterBeanMap =  new HashMap<String, List<EntityForeignKeyDetailMasterBean>>();
		List<String> constraintNames = getContraintNamesFromTB_FK_Master(conn);
		for(String constraintName: constraintNames){
			//System.out.println("LabelCache.populateEntityPrimaryKeyInfoBeans()"+entityName);
			List<EntityForeignKeyDetailMasterBean> foriegnKeyInfoBeanList = getConstraintDetails(conn, constraintName);
			constraintNameEntityForeignKeyDetailsMasterBeanMap.put(constraintName, foriegnKeyInfoBeanList);
		}
		return constraintNameEntityForeignKeyDetailsMasterBeanMap;
	}	

	
	
	private static List<EntityForeignKeyDetailMasterBean> getConstraintDetails(Connection conn, String constraintName) throws FrameWorkSystemException {
		String sql = Queries.GET_CONSTRAINT_DETAILS_FROM_TB_FK_DETAIL_MASTER;
		List<EntityForeignKeyDetailMasterBean> list1=new ArrayList<EntityForeignKeyDetailMasterBean>();
		List<Map> map= new ResourceManager().executePreparedStatement(conn,  sql, constraintName);
		for(Map map1: map){
			EntityForeignKeyDetailMasterBean e = new EntityForeignKeyDetailMasterBean();
			e.setContraintName(((String)map1.get("CONSTRAINT_NAME")));
			e.setTableName(((String)map1.get("TABLE_NAME")));
			e.setColumnName(((String)map1.get("COLUMN_NAME")));
			e.setrTableName(((String)map1.get("R_TABLE_NAME")));
			e.setrColumnName(((String)map1.get("R_COLUMN_NAME")));
			list1.add(e);		
		}
		return list1;
	}
	
	private static List<String> getContraintNamesFromTB_FK_Master(Connection conn) throws FrameWorkSystemException {
		List<String> constraintList = new ArrayList<String>();
		String sql = Queries.GET_DISTINCT_CONSTRAINT_NAMES_FROM_TB_ENT_FK_DETAIL_MASTER; 
		List<Map> contraintNameMapList=new ResourceManager().executePreparedStatement(conn,sql);
		for(Map constraintMap: contraintNameMapList){
			constraintList.add((String)constraintMap.get("CONSTRAINT_NAME"));
		}
		return constraintList;
	}
	private static Map<String,List<EntityLinkDetailMasterBean>> populateAppTypeParentEntityChildEntityNameListLinkDetailMasterBeanMap() throws FrameWorkSystemException{
		Map<String,List<EntityLinkDetailMasterBean>> map=new HashMap<String,List<EntityLinkDetailMasterBean>>();
		Map<String,	List<EntityLinkMasterBean>> appTypeToEntityLinkMasterBeanListMap=getAppTypeEntityLinkMasterBeanMap();
		Set<String> appTypeSet=appTypeToEntityLinkMasterBeanListMap.keySet();
		String mapKey="";
		for(String appType:appTypeSet){
			List<EntityLinkMasterBean> entityLinkMasterBeanList=appTypeToEntityLinkMasterBeanListMap.get(appType) ;
			Set<String> childEntityNameSet =getChildEntities(entityLinkMasterBeanList);
			
			for(String childEntityName:childEntityNameSet){
				
				if(childEntityName.equalsIgnoreCase("Label")){
					System.out.println("Label");
				}
				Map<String,List<EntityLinkDetailMasterBean>> parentlinkDetailMasterBeanMap=new HashMap<String, List<EntityLinkDetailMasterBean>>();
				for(EntityLinkMasterBean bean:entityLinkMasterBeanList){
					if(childEntityName.equalsIgnoreCase(bean.getEntityName())){
						String parentEntityName=bean.getParentEntityName();
						mapKey=appType+"."+parentEntityName+"."+childEntityName;
						List<EntityLinkDetailMasterBean> linkDetailMasterBeans=getEntityLinkDetailsMasterBeanMapFromParentEntityNames(childEntityName, bean.getParentEntityName());
						map.put(mapKey, linkDetailMasterBeans);
					}
				
				}
				//map.put(childEntityName, parentlinkDetailMasterBeanMap);
			}
		}
		List<EntityLinkDetailMasterBean> l1=map.get("SystemSetup.SystemSetupDummyEntity.Label");
		List<EntityLinkDetailMasterBean> l2=map.get("PropertyConsole.PropertyConsoleDummyEntity.Label");
		List<EntityLinkDetailMasterBean> l3=map.get("Workspace.WorkspaceDummyEntity.Label");
		List<EntityLinkDetailMasterBean> l4=map.get("Application.Application.Label");
		return map;	
		
	}
	
	private static Set<String> getChildEntities(List<EntityLinkMasterBean> entityLinkMasterBean){
		Set<String> childEntityNameSet=new TreeSet<String>();
		for(EntityLinkMasterBean bean: entityLinkMasterBean)
			childEntityNameSet.add(bean.getEntityName());
		return childEntityNameSet;
	}
	private static List<EntityLinkDetailMasterBean> getEntityLinkDetailsMasterBeanMapFromParentEntityNames(String entityName, String parentEntityName) throws FrameWorkSystemException {
		List<EntityLinkDetailMasterBean> entityLinkDetailsMasterBeanList = new ArrayList<EntityLinkDetailMasterBean>();
		Map<String, List<EntityLinkDetailMasterBean>> entityNameEntityLinkDetailsMasterBeanMap = LabelCache.getEntityNameEntityLinkDetailsMasterBeanMap();
		Set<String> entityNameSet=entityNameEntityLinkDetailsMasterBeanMap.keySet();
		for(String entityName1:entityNameSet){
			List<EntityLinkDetailMasterBean> entityLinkDetailsMasterBeans = entityNameEntityLinkDetailsMasterBeanMap.get(entityName1);
			for(EntityLinkDetailMasterBean eldmb: entityLinkDetailsMasterBeans){
				String parentEntityName2=eldmb.getParentEntityName();
				String entityName2=eldmb.getEntityName();
				
				if(parentEntityName.equalsIgnoreCase(eldmb.getParentEntityName()) && entityName.equalsIgnoreCase(eldmb.getEntityName())){
					entityLinkDetailsMasterBeanList.add(eldmb);
				}
			}
		}
		return entityLinkDetailsMasterBeanList;
	}
	
	public static SystemEntityVo getSystemEntityVo(String entityName, boolean heirarchyFlag) throws FrameWorkSystemException{
		String appType = getAppType(entityName);
		return getSystemEntityVo(appType, entityName, heirarchyFlag);
	}
	
	public static SystemEntityVo getSystemEntityVo(String appType, String entityName, boolean heirarchyFlag) throws FrameWorkSystemException{
		String rootEntityName = entityName;
		while(hasParentEntity(appType, rootEntityName)){
			String parentEntityName = getParentEntityName(appType, rootEntityName);
			rootEntityName = parentEntityName;
		}
		
		//Given Entity is a 'Root' entity
		if(rootEntityName.equalsIgnoreCase(entityName))
			return getVo(appType, entityName);
		
		SystemEntityVo vo = getVo(appType, rootEntityName);
		if(!heirarchyFlag)
			return get(vo.getChildrenEntities(), entityName);
		return vo;
	}
	
	private static SystemEntityVo get(Set<SystemEntityVo> entities, String entityName){
		if(entities == null || entities.size() == 0) return null;
		for(SystemEntityVo entity: entities){
			if(entity.getEntityName().equals(entityName))
				return entity;
			else 
				return get(entity.getChildrenEntities(), entityName);
		}
		return null;
	}
	
	private static SystemEntityVo getVo(String appType, String entityName) throws FrameWorkSystemException{
		
		SystemEntityVo vo = new SystemEntityVo();
		ArrayList<EntityLinkDetailMasterBean> entityLinkDetailMasterObj = null;
		vo.setEntityName(entityName);
		vo.setParentTable(getParentTable(appType, entityName));
		entityLinkDetailMasterObj = (ArrayList<EntityLinkDetailMasterBean>) getEntityNameEntityLinkDetailsMasterBeanMap().get(entityName);
		if(entityLinkDetailMasterObj != null)
			vo.setRelationToParent(getEntityRelationToParent(entityLinkDetailMasterObj, entityName));
		if(hasChildEntity(appType, entityName)) {
			List<String> childEntityNameList = getChildEntityName(appType, entityName);
			for(String childEntityName: childEntityNameList){
				vo.addChildrenEntity(getVo(appType, childEntityName));
			}
		}
		return vo;
	}
	
	private static List<EntityLinkToParent> getEntityRelationToParent(List<EntityLinkDetailMasterBean> entityLinkageList, String entityName) {
		ArrayList<EntityLinkToParent> linkToParentList = new ArrayList<EntityLinkToParent>();
		EntityLinkToParent parentObj = null;
		for(EntityLinkDetailMasterBean entityLinkObj : entityLinkageList) {
			if(entityName.equals(entityLinkObj.getEntityName()))
			{
				parentObj = new EntityLinkToParent();
				parentObj.setParentEntity(entityLinkObj.getParentEntityName());
				parentObj.setParentTableName(entityLinkObj.getParentTableName());
				parentObj.setParentColumnName(entityLinkObj.getParentTableColumnName());
				parentObj.setChildTableName(entityLinkObj.getEntityTableName());
				parentObj.setChildColumnName(entityLinkObj.getEntityTableColumnName());
				linkToParentList.add(parentObj);
			}
		}
		return linkToParentList;
	}
	
	private static EntityLinkMasterBean getLinkMasterBean(String appType, String entityName) throws FrameWorkSystemException{
		Map<String, List<EntityLinkMasterBean>> appTypeEntityLinkMasterBeanMap = LabelCache.getAppTypeEntityLinkMasterBeanMap();
		for(String type: appTypeEntityLinkMasterBeanMap.keySet()){
			if(type.equalsIgnoreCase(appType)){
				List<EntityLinkMasterBean> linkMasterBeanList = appTypeEntityLinkMasterBeanMap.get(type);
				for(EntityLinkMasterBean linkMasterBean : linkMasterBeanList){
					if(linkMasterBean.getEntityName().equalsIgnoreCase(entityName)){
						return linkMasterBean;
					}
				}
			}
		}
		return null;
	}
	
	private static EntityLinkMasterBean getLinkMasterBean(String entityName) throws FrameWorkSystemException{
		Map<String, List<EntityLinkMasterBean>> appTypeEntityLinkMasterBeanMap = LabelCache.getAppTypeEntityLinkMasterBeanMap();
		for(String type: appTypeEntityLinkMasterBeanMap.keySet()){
			List<EntityLinkMasterBean> linkMasterBeanList = appTypeEntityLinkMasterBeanMap.get(type);
			for(EntityLinkMasterBean linkMasterBean : linkMasterBeanList){
				if(linkMasterBean.getEntityName().equalsIgnoreCase(entityName)){
					return linkMasterBean;
				}
			}
		}
		return null;
	}
	
	private static boolean hasParentEntity(String appType, String entityName) throws FrameWorkSystemException{
		EntityLinkMasterBean linkMasterBean = getLinkMasterBean(appType, entityName);
		return !linkMasterBean.getParentEntityName().equals("Root");
	}
	
	private static String getParentEntityName(String appType, String entityName) throws FrameWorkSystemException{
		EntityLinkMasterBean linkMasterBean = getLinkMasterBean(appType, entityName);
		return linkMasterBean.getParentEntityName();
	}
	
	private static boolean hasChildEntity(String appType, String entityName) throws FrameWorkSystemException{
		EntityLinkMasterBean linkMasterBean = getLinkMasterBean(appType, entityName);
		return linkMasterBean.getHasChild().equals("Y");
	}
	
	private static List<String> getChildEntityName(String appType, String entityName) throws FrameWorkSystemException{
		List<String> childNameList = new ArrayList<String>();
		Map<String, List<EntityLinkMasterBean>> typeEntityLinkMasterBeanMap = getAppTypeEntityLinkMasterBeanMap();
		for(String type: typeEntityLinkMasterBeanMap.keySet()){
			if(type.equalsIgnoreCase(appType)){
				List<EntityLinkMasterBean> list = typeEntityLinkMasterBeanMap.get(type);
				for(EntityLinkMasterBean linkMasterBean: list){
					if(linkMasterBean.getParentEntityName().equalsIgnoreCase(entityName)){
						childNameList.add(linkMasterBean.getEntityName());
					}
				}
			}
		}
		return childNameList;
	}
	
	private static List<EntityColumnInfoBean> getEntityColumnMasterBeanList(String tableName) throws FrameWorkSystemException{
		return getTableNameEntityColumnInfoBeanMap().get(tableName);
	}
	
	private static String getAppType(String entityName) throws FrameWorkSystemException{
		return getLinkMasterBean(entityName).getAppType();
	}
	
	public static void main(String[] args) throws FrameWorkSystemException {
		getEntityNameEntityLinkDetailsMasterBeanMap();
		String appType = "Txn_Entity";
		String entityName = "Customer";
		SystemEntityVo systemEntityVo = getSystemEntityVo(appType, entityName, false);
		System.out.println(systemEntityVo);
		 Gson gson = new GsonBuilder()
	        .setExclusionStrategies(new ExclusionStrategy() {
				
				@Override
				public boolean shouldSkipField(FieldAttributes f) {
					return (f.getDeclaringClass() == SystemEntityVo.class && f.getName().equals("parentEntity"));
				}
				
				@Override
				public boolean shouldSkipClass(Class<?> arg0) {
					return false;
				}
			}).create();
		System.out.println(gson.toJson(systemEntityVo, SystemEntityVo.class));
	}
	
	private static Table getParentTable(String appType, String entityName) throws FrameWorkSystemException{
		Table table = null;
		for(String entity: getEntityNameEntityMasterBeanMap().keySet()){
			if(entity.equals(entityName) && getTableNamesInInsertOrder().get(appType).get(entityName) != null){
				List<EntityMasterBean> entityMasterBeanList =  getEntityNameEntityMasterBeanMap().get(entity);
				for(EntityMasterBean masterBean: entityMasterBeanList){
					if(masterBean.getIsPrimary().equals("Y")){
						String tableName = masterBean.getTableName();
						table = new Table();
						table.setName(tableName);
						table.setColumns(getColumns(entityName, tableName));
						table.setChildren(getChildTable(entityName, tableName));
						table.setChildTableLinks(getChildTableLinkages(entityName, tableName));
						return table;
					}
				}
			}
		}
		return table;
	}
	
	private static ArrayList<EntityLinkToParent> getChildTableLinkages(String entityName, String tableName)  throws FrameWorkSystemException {
		List<EntityDetailMasterBean> list = getEntityNameEntityDetailMasterBeanMap().get(entityName);
		EntityLinkToParent childTableLinkages = null;
		ArrayList<EntityLinkToParent> childTableLinkList = new ArrayList<EntityLinkToParent>();
		if(list != null){
			for(EntityDetailMasterBean detailMasterBean: list){
				if(detailMasterBean.getTableName().equals(tableName) && detailMasterBean.getEntityName().equals(entityName)){
					childTableLinkages = new EntityLinkToParent();
					childTableLinkages.setParentEntity(entityName);
					childTableLinkages.setParentTableName(tableName);
					childTableLinkages.setParentColumnName(detailMasterBean.getColumnName());
					childTableLinkages.setChildTableName(detailMasterBean.getChildTableName());
					childTableLinkages.setChildColumnName(detailMasterBean.getChildColumnName());
					
					childTableLinkList.add(childTableLinkages);
				}
			}
		}
		return childTableLinkList;
	}
	
	private static Set<Table> getChildTable(String entityName, String tableName) throws FrameWorkSystemException{
		List<EntityDetailMasterBean> list = getEntityNameEntityDetailMasterBeanMap().get(entityName);
		Set<String> childTableNameSet = new HashSet<String>();
		Set<Table> tables = null;
		
		if(list != null){
			tables = new HashSet<Table>();
			for(EntityDetailMasterBean detailMasterBean: list){
				if(detailMasterBean.getTableName().equals(tableName) && detailMasterBean.getEntityName().equals(entityName)){
					String childTableName = detailMasterBean.getChildTableName();
					if(childTableNameSet.contains(childTableName)) continue;
					childTableNameSet.add(childTableName);
					Table table = new Table();
					table.setName(childTableName);
					table.setColumns(getColumns(entityName, childTableName));
					table.setChildTableLinks(getChildTableLinkages(entityName, tableName));
					
					if(hasChildrenTable(entityName, childTableName)){
						table.setChildren(getChildTable(entityName, childTableName));
					}
					tables.add(table);
				}
			}
		}
		return tables;
	}
	
	private static boolean hasChildrenTable(String entityName, String tableName) throws FrameWorkSystemException{
		List<EntityDetailMasterBean> list = getEntityNameEntityDetailMasterBeanMap().get(entityName);
		if(list != null){
			for(EntityDetailMasterBean detailMasterBean: list){
				if(detailMasterBean.getTableName().equals(tableName) && detailMasterBean.getEntityName().equals(entityName)){
					return true;
				}
			}
		}
		return false;
	}
	
	private static Set<Column> getColumns(String entityName, String tableName) throws FrameWorkSystemException{
		Set<Column> columns = new HashSet<Column>();
		List<EntityColumnInfoBean> entityColumnMasterBeanList = getEntityColumnMasterBeanList(tableName);
		for(EntityColumnInfoBean columnInfoBean: entityColumnMasterBeanList){
			Column col = new Column();
			String datatype = columnInfoBean.getDataType(); 
			String name = columnInfoBean.getColumnName();
			col.setDatatype(datatype);
			col.setName(name);
			col.setPrimary(isPrimary(entityName, tableName, name));
			columns.add(col);
		}
		return columns;
	}
	
	private static boolean isPrimary(String entityName, String tableName, String columnName) throws FrameWorkSystemException{
		Map<String, List<EntityPrimaryKeyMasterBean>> entityNameToPrimaryKeyMasterBeanList = getEntityNameEntityPrimaryKeyMasterBeanMap();
		
		List<EntityPrimaryKeyMasterBean> primaryKeyMasterBeanList = entityNameToPrimaryKeyMasterBeanList.get(entityName);
		if(primaryKeyMasterBeanList == null) {
			String msg = "EntityPrimaryKeyMasterBean is not defined for entity '" + entityName + ",";
			Exception e = new FrameWorkSystemException(LabelCache.class, msg, null);
			mLog.fatal(e.getMessage(), e);
			throw new FrameWorkSystemException(LabelCache.class, msg, e);
		}
		
		for(EntityPrimaryKeyMasterBean primaryKeyMasterBean: primaryKeyMasterBeanList){
			if(primaryKeyMasterBean.getTableName().equalsIgnoreCase(tableName) && primaryKeyMasterBean.getColumnName().equalsIgnoreCase(columnName))
				return true;
		}
		return false;
	}
}
