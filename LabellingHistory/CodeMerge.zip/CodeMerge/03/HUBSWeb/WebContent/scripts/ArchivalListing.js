var gridSelectedRecords = [];
var monName=new Array("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC");

function init(){
//	loadEntityName();
	initializeDatePicker();
}

/*function loadEntityName(){
	alert("Entity Nam");
	var entityDropDown=form.getFieldById('entityName');
	console.dir(entityDropDown);
	entityDropDown.setQueryCode('ARCHIVAL_ENTITY');
	entityDropDown.loadData();
//	console.dir(getUnuthorizedEntityData(1228));
}*/

function initializeDatePicker(){
	
	$("#effectiveDate, #expiryDate").datepicker({
		dateFormat:"dd/mm/yy",
		changeYear:true,
		changeMonth:true,
		showOn: 'both',
		buttonImage: 'images/calendar_2.gif',
		buttonImageOnly: true
    });
}

function doSearch(){
	var gridId = getGridId();
	console.log("gridId: " + gridId)
	var grid1 = gridDetailsArray[gridId];
	var searchJSONString = JSON.stringify(getSearchCriteria());
	grid1.setSearchCrt(searchJSONString);
	grid1.setDiv('resultGrid');
	grid1.setShowHeader(true);
	grid1.setShowFrame(true);
	grid1.setHeight(300);
	if(isArchive == "Y"){
		var selectionConfig = new Object();
		selectionConfig.selectionType = 'checkbox';
		selectionConfig.selectionHandler = gridSelectionHandler;
		grid1.setSelectionModel(selectionConfig);
	}
	grid1.createGrid();

	return;
	//displayBottomPanelButton();
	
	function getGridId(){
		if(isArchive == "Y") return 8005;
	}

	
	function getSearchCriteria(){
		var searchCriteria = new Array();
//		var entityName = $("#entityName").val() == "NA" ? "" : $("#entityName").val();
//		alert("Entity Name: " + entityName);
		addToCriteria($("#archivalName").val(), "NAME", "LIKE", searchCriteria);
		addToCriteria($("#datasource").val(), "DATASOURCE", "=", searchCriteria);
		addToCriteria(getDateInOracleFormat($("#effectiveDate").val()), "EFFECTIVE_DATE", "=", searchCriteria);
		addToCriteria(getDateInOracleFormat($("#expiryDate").val()), "EXPIRY_DATE", "=", searchCriteria);
		addToCriteria($("#entityName").val() , "ENTITY_NAME", "LIKE", searchCriteria);
		
		searchCriteria.push({"name" : "IS_ARCHIVE", "operator" : "=", "value" : isArchive});
		console.dir(searchCriteria);
		return searchCriteria;
		
		//dd-MON-yyyy
		function getDateInOracleFormat(val){
			if(val == "") return "";
			val = val.split("/");
			var date = val[0];
			var month = val[1];
			var year = val[2];
			console.log(date + "-" + monName[parseInt(month, 10) - 1] + "-" + year);
			return date + "-" + monName[parseInt(month, 10) - 1] + "-" + year;
		}
		
		function addToCriteria(val, dbColumn, operator, searchCriteria){
			if(val != "")
				searchCriteria.push({"name" : dbColumn, "operator" : operator, "value" : val});
		}
	}

	function displayBottomPanelButton(){
		if(wfaction == 'authReject'){
			document.getElementById('checkerAuthorize').style.display = "block";
		} else if (wfaction == 'modifyDelete'){
			document.getElementById('makerModify').style.display = "block";
		} else if (wfaction == 'checkersearch_frame'){
			document.getElementById('checkerUnauthView').style.display = "block";
		}
	}
}

function gridSelectionHandler(selectedObjs){
	gridSelectedRecords = [];
	for(var key in selectedObjs){
		if (selectedObjs.hasOwnProperty(key)) {
			gridSelectedRecords.push(selectedObjs[key].data);
		}
	}
	//console.dir(gridSelectedRecords);
}

function doClear(){
	$("#archivalName").val("");
	setFirstOption("#datasource");
	$("#effectiveDate").val("");
	$("#expiryDate").val("");
	$("#entityName").val("");
}

function setFirstOption(selector){
	$(selector).val($(selector + " option:first").val());
}

function doSchedule(){
	var archivalNamesCommaSeparated = "";
	for(var key in gridSelectedRecords){
		if (gridSelectedRecords.hasOwnProperty(key)) {
			var gridRecord = gridSelectedRecords[key];
			console.dir(gridRecord);
			archivalNamesCommaSeparated += gridRecord["ar_name"] + ",";
		}
	}
	if(gridSelectedRecords.length == 0) {
		alert("Select Record to Archive");
		return;
	}
	window.open("ArchivalSchedule.jsp?isArchive="+isArchive + "&viewId=8006&archivalName=" + archivalNamesCommaSeparated,"","alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60");
}