//alertErrorMessage("sdf15!!!");
var systemEntityVo;
var datatypeOperatorMap = {
	"NUMBER" : ["=","!=","<","<=",">",">=","IsNull","IsNotNull"],
	"VARCHAR2": ["=","!=","StartsWith","EndsWith","IsNull","IsNotNull","Contains"],
	"DATE" : ["=","!=","<","<=",">",">=","IsNull","IsNotNull"],
	"TIMESTAMP": ["=","!=","<","<=",">",">=","IsNull","IsNotNull"],
	"CHAR": ["=","!=","StartsWith","EndsWith","IsNull","IsNotNull","Contains"]
}
var ruleGridConfigArr = [
         			 {"id":"openBrace", "index":0, "label": "Brace"},
        	         {"id":"tableName", "index":1, "label": "Table Name"},
        	         {"id":"fieldName", "index":2, "label": "Field Name"},
        	         {"id":"filterOperator", "index":3, "label": "Operator"},
        	         {"id":"filterValue", "index":4, "label": "Value"},
        	         {"id":"closeBrace", "index":5, "label": "Close Brace"}
        	         ];
var vGridSelectedObj;
var gridSelectedRecords = [];

var monName=new Array("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC");

function loadEntityName(){
	var entityDropDown=form.getFieldById('entityName');
	entityDropDown.setQueryCode('ARCHIVAL_ENTITY');
	entityDropDown.loadData();
//	console.dir(getUnuthorizedEntityData(1228));
}

var mjQueryDtFormat = 'dd/mm/yy'; 
$(function() {
	$("#effectiveDate, #expiryDate").datepicker({
		dateFormat:mjQueryDtFormat,
		changeYear:true,
		changeMonth:true,
		showOn: 'both',
		 buttonImage: 'images/calendar_2.gif',
		 buttonImageOnly: true
    });
	
});

function doSave(){
	saveArchivalDefinition();
}

function saveArchivalDefinition(){
	if(!validation()){
		alert("Validation failed");
		return;
	}
	if(isMakerNew()){
		saveNewArchivalDefinition();
	} else if (isMakerAuthModify()){
		modifyAuthArchivalDefinition();
	} else if (isMakerUnauthModify()){
		modifyAuthArchivalDefinition();
	} else {
		alert("Cannot be Saved");
	}
}

function getData(){
	var data = form.getFieldDataJSON();
	
	if(isMakerNew()){
		//screenDetail.wfaction == "new"
		data["action"] = "new";
		data["status"] = "unauth";
		data["makerId"] = userId;
		data["isArchive"] = isArchive;
	} else if (isMakerAuthModify()){
		//(screenDetail.wfaction == "modifyDelete" && screenDetail.status == "auth")
		data["action"] = "modify";
		data["status"] = "auth";
		data["isArchive"] = isArchive;
		data["name"] = archivalName;
		data["id"] = archivalId;
		data["makerId"] = userId;
	} else if (isMakerUnauthModify()){
		//(screenDetail.wfaction == "modifyDelete" && screenDetail.status == "auth")
		data["action"] = "modify";
		data["status"] = "unauth";
		data["isArchive"] = isArchive;
		data["name"] = archivalName;
		data["id"] = archivalId;
		data["makerId"] = userId;
	}
	alert("isArchive: " + isArchive + ", UserId: " + userId);
	return data;
}

function saveNewArchivalDefinition(){
	var formData = getData();
	var vFormRecord = {"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity", "dbOperation" : "save", "entityData" : formData};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"insertIntoWorkTable", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,function(data){
		if(data.success){
			wfAlert( data.message);
		} else{
			wfAlert("Exception : " + data.message + ".");
		}
	});
	
}

function getAuthorizedEntityData(archivalName, archivalId){
	var data = {};
	var entityData = {};
	data["name"] = archivalName;
	data["id"] = parseInt(archivalId);
	var vFormRecord = {"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity", "dbOperation" : "save", "entityData" : data};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"getAuthorizedRecord", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,{ 
        async: false,
        callback: function(data){
    		if(data.success){
    			entityData = JSON.parse(data.data);
    			entityData.archivalEntityRuleGrid = JSON.parse(entityData.archivalEntityRuleGrid);
    		} else{
    			wfAlert("Exception : " + data.message + ".");
    		}
    	}
    });
	
	return entityData;
}

function getUnauthorizedEntityData(reqId){
	var data = {};
	var entityData = {};
	data["reqid"] = reqId;
	var vFormRecord = {"entityname" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity", "dbOperation" : "save", "entityData" : data};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"getUnauthorizedRecord", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore"};
	console.log("-> Entity Data");
	console.dir(entityData);
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,{ 
        async: false,
        callback: function(data){
    		if(data.success){
    			entityData = JSON.parse(data.data);
    			entityData.archivalEntityRuleGrid = JSON.parse(entityData.archivalEntityRuleGrid);
    			loadEntityData(entityData);
    		} else{
    			wfAlert("Exception : " + data.message + ".");
    		}
    	}
    });
	return entityData;
}

function doDelete(){
	var status = $("#status").val();
	if(status == 'auth'){
		doDeleteAuthorize();
	} else {
		doDeleteUnauthorize();
	}
	}

function doDeleteUnauthorize(){
	var entityDataArray = [];
	var status = $("#status").val();
	
	if (gridSelectedRecords && gridSelectedRecords.length>0) {
		for ( var key in gridSelectedRecords) {
			
			if (gridSelectedRecords.hasOwnProperty(key)) {
				var gridRecord = gridSelectedRecords[key];
				console.dir(gridRecord);
				var str = gridRecord['ar_name'].split("#");
				var id = parseInt(str[0]);
				var name = str[1];
				var action = 'delete';
				var reqId = gridRecord['reqid'];
//				var entityData = getAuthorizedEntityData(name, id);
				var entityData = {};
				entityData.makerId = user;
				entityData.action = action;
				entityData.status = status;
				entityData.reqId = reqId;
				entityDataArray.push({
					"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity",
					"dbOperation" : 'save',
					"entityData" : entityData
				});
//				console.dir(archivalDefinitionEntity);
			}
		}
	}else {
		alertErrorMessage("Select Records to authorize");
		return false;
	}
	
	console.dir(entityDataArray);
	var jsonData = new Object();
	jsonData.data = JSON.stringify(entityDataArray);

	var jsonInvokeInfo = {"ajaxMethod":"deleteAplicationMaintenance", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore" };
//	alertErrorMessage(jsonInvokeInfo);
	console.dir(jsonData);
	GenericDwr.invokeMethod(jsonInvokeInfo, jsonData, function(data) {
		if (data.success) {
			wfAlert(data.message);//1.1
//			doSearch();
		} else {
			alertErrorMessage("Error : " + data.message+ ".");
		}
	});

}

function doDeleteAuthorize(){
	var status = $("#status").val();
	var entityDataArray = [];
	
	if (gridSelectedRecords && gridSelectedRecords.length>0) {
		for ( var key in gridSelectedRecords) {
			
			if (gridSelectedRecords.hasOwnProperty(key)) {
				var record = gridSelectedRecords[key];
				var str = record['ar_name'].split("#");
				var id = parseInt(str[0]);
				var name = str[1];
				var action = 'delete';
				var entityData = getAuthorizedEntityData(name, id);
				entityData.makerId = user;
				entityData.action = action;
				entityData.status = status;
				entityDataArray.push({
					"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity",
					"dbOperation" : 'save',
					"entityData" : entityData
				});
//				console.dir(archivalDefinitionEntity);
			}
		}
	}else {
		alertErrorMessage("Select Records to authorize");
		return false;
	}
	
	console.dir(entityDataArray);
	var jsonData = new Object();
	jsonData.data = JSON.stringify(entityDataArray);

	var jsonInvokeInfo = {"ajaxMethod":"deleteAplicationMaintenance", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore" };
//	alertErrorMessage(jsonInvokeInfo);
	console.dir(jsonData);
	GenericDwr.invokeMethod(jsonInvokeInfo, jsonData, function(data) {
		if (data.success) {
			wfAlert(data.message);//1.1
			doSearch();
		} else {
			Ext.MessageBox.alertErrorMessage("Message", "Exception : " + data.message+ ".", false);
		}
	});
}

function modifyAuthArchivalDefinition(){
	var formData = getData();
	var vFormRecord = {"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity", "dbOperation" : "save", "entityData" : formData};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"insertIntoWorkTable", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,function(data){
		if(data.success){
			wfAlert( data.message);
		} else{
			wfAlert("Exception : " + data.message + ".");
		}
	});
	
}

function createRuleGrid(arr){
	document.getElementById('archivalEntityRuleGrid').innerHTML = "";
	
	var applicationEntityGrid = new Grid();
	applicationEntityGrid.setGridId('archivalEntityRuleGrid');
	applicationEntityGrid.setPageSize(10);

	addGridFields(applicationEntityGrid, ruleGridConfigArr);
	
	applicationEntityGrid.setDiv('archivalEntityRuleGrid');
	//applicationEntityGrid.setHeight(document.documentElement.offsetHeight - 115);
	//alert("isMakerAuthView(): " + isMakerAuthView());
	
	applicationEntityGrid.addEventListeners('beforeAdd', preProcessAdd);
	applicationEntityGrid.addEventListeners('add', postProcessAdd);
	applicationEntityGrid.addEventListeners('select', onSelect);
	applicationEntityGrid.addEventListeners('modify', onModify);
	//applicationEntityGrid.addEventListeners('beforeModify', preProcessModify);
	applicationEntityGrid.addEventListeners('delete', onDelete);
	// Start
		/*var selectionConfig = new Object();
		selectionConfig.selectionType = 'checkbox';
		selectionConfig.selectionHandler = populateSelectedList;
		applicationEntityGrid.setSelectionModel(selectionConfig);*/
	// End
//	if(jsAction=="checkersearch_frame" || jsAction=="makersearch_frame")
//	{
//	}
	if(isMakerUnauthView() || isMakerAuthView() || isCheckerUnauthView() || isCheckerAuthView()){
		applicationEntityGrid.setToolbarVisible(false);
	} else {
		applicationEntityGrid.setToolbarVisible(true);
	}
	applicationEntityGrid.renderGrid();
	applicationEntityGrid.extGrid.setHeight(300);
//	applicationEntityGrid.setHeight(200);
	if(isMakerAuthModify() || isMakerUnauthModify() || isMakerUnauthView() || isMakerAuthView() || isCheckerUnauthView() || isCheckerAuthView()){
//	if(arr) 
		form.getGridById('archivalEntityRuleGrid').loadRows(arr, false);
	}
	//alertErrorMessage("gStatus "+gStatus+" jsAction "+jsAction+" lreqId "+lreqId+"")
//	if(jsAction && jsAction != 'new' && lreqId>0 && (gStatus=='unauth' || gStatus=='draft')){
//			mapJSONToForm(jsonResponse);
//	}else if(jsAction && jsAction != 'new' && lreqId>0 && gStatus=='auth')
//			{
//				mapJSONToForm(jsonResponse);
//			}

	
	return applicationEntityGrid;
} 

function postProcessAdd(){
	resetGridFields();
	setTableSelection($('#entityName option:selected').text());
	return true;
}

function onDelete(){
	var formData = form.getFieldDataJSON(); 
	var gridDataArrayObject={};
	gridDataArrayObject = formData.archivalEntityRuleGrid;
	if(gridDataArrayObject && gridDataArrayObject.length > 0){
		var gridRecordObject;
		for(var i=0; i < gridDataArrayObject.length; i++){
			gridRecordObject = gridDataArrayObject[i];
			if((gridRecordObject.tableName==vGridSelectedObj.data.tableName))
			{
//				alertErrorMessage("Got It!!!");
//				gridRecordObject.action='delete';
//				form.getFieldById('totalCount').setValue(parseInt(form.getFieldById('totalCount').getValue())-1);
//				form.getFieldById('seqNo').setValue(form.getFieldById('totalCount').getValue());
				formData.archivalEntityRuleGrid.splice(i, 1);
				form.getFieldDataJSON().archivalEntityRuleGrid=formData.applicationEntityGrid;
				break;
			}
		}
	 }
	return true;
}

function onModify(){
	if(validateMandatoryGridFieldValues() && validateValueAndDatatype()){
		setGridFieldValues();
		return true;
	}
	return false;
}

function preProcessAdd(){
	if(validateMandatoryGridFieldValues() && validateValueAndDatatype()){
		setGridFieldValues();
		return true;
	} else {
		return false;
	}
	
}

function validateValueAndDatatype(){
	var datatype = $("#fieldSelection option:selected").val();
	var value = $("#filterText").val();
	return validateValueByDatatype(value, datatype);
}

function isOptionSelected(selectorId, val){
	return $("#" + selectorId+" option:selected").val() != val;
}

function validateMandatoryGridFieldValues(){
	if($("#tableSelection option:selected").val() == 'NA'){
		alertErrorMessage('Select Table');
		return false;
	} 
	if($("#fieldSelection option:selected").val() == 'NA'){
		alertErrorMessage('Select Field');
		return false;
	} 
	if($("#operatorSelection option:selected").val() == 'NA'){
		alertErrorMessage('Select Operator');
		return false;
	} 
	
	if($("#filterText").val() == ''){
		alertErrorMessage('Enter Value');
		return false;
	} 
	
	return true;
}

function onSelect(selectedRowObj){
	vGridSelectedObj = selectedRowObj;
	setValuesOnGridSelection(selectedRowObj.data)
}

function setValuesOnGridSelection(data){
	console.dir(data);
	var entityName = $('#entityName option:selected').text();
	var openBrace = data.openBrace;
	var tableName = data.tableName;
	var fieldName = data.fieldName;
	var filterOperator = data.filterOperator;
	var filterValue = data.filterValue;
	var closeBrace = data.closeBrace;
	
	resetGridFields()
	
//	resetOpeningBraceSelection();
//	console.log("Entity Name: " + entityName);
	setTableSelection(entityName);
//	console.log("Table Name: " + tableName);
	setColumnSelection(tableName);
//	console.log("Field Name: " + fieldName);
//	console.log("Datatype: " + getSelectValueBasedOnText("#fieldSelection", fieldName));
	setOperatorSelection(getSelectValueBasedOnText("#fieldSelection", fieldName));
	
//	resetClosingBraceSelection();
	
	
	setSelectionOptionBasedOnText("#openingBraceSelection", openBrace);
	setSelectionOptionBasedOnText("#tableSelection", tableName);
//	console.log("Column Name: " + columnName);
	setSelectionOptionBasedOnText("#fieldSelection", fieldName);
	setSelectionOptionBasedOnText("#operatorSelection", filterOperator);
	$('#filterText').val(filterValue);
	console.log("Close Brace: '" + closeBrace + "'");
	setSelectionOptionBasedOnText("#closingBraceSelection", closeBrace);
	
}

function resetOpeningBraceSelection(){
	var items = ['('];
	$.each(items, function (i, item) {
	    $('#openingBraceSelection').append($('<option>', { 
	        value: item,
	        text : item 
	    }));
	});
}

function resetClosingBraceSelection(){
	var items = [')', 'AND', 'OR', ') AND', ') OR'];
	$.each(items, function (i, item) {
	    $('#closingBraceSelection').append($('<option>', { 
	        value: item,
	        text : item 
	    }));
	});
}

function setSelectionOptionBasedOnText(selector, text){
	$(selector + " option").filter(function() {
//		console.log(this.text == text);
	    return this.text == text; 
	}).attr('selected', true);
}

function getSelectValueBasedOnText(selector, text){
	var value ;
	$(selector + " option").each(function(a,b) {
	     if ($(this).html() == text) {
	    	 value = $(this).attr('value');
	     }
	});
	return value;
}

function resetGridFields(){
	removeOptionExceptFirst(['#openingBraceSelection','#tableSelection', '#fieldSelection', '#operatorSelection', '#closingBraceSelection']);
	clearTextInput('#filterText');
	$('#filterText').val('');
	resetOpeningBraceSelection();
	resetClosingBraceSelection();
}

//Event Handlers for Selections
//Handler for Entity Name Selection
function entityNameHandler(){
	populateSystemEntityVo();
	clearGrid('archivalEntityRuleGrid');
}

function populateSystemEntityVo(){
	if($("#entityName option:selected").val() == "NA")
		return;
	var entityName = $("#entityName option:selected").text();
	
	var vFormRecord = {"entityName" : entityName};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	//alertErrorMessage("jsonData.data "+jsonData.data);
	var jsonInvokeInfo = {"ajaxMethod":"getSystemEntityVo", "ajaxClass":"com.polaris.workflow.store.APSystemEntity_Store"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,function(data){
		if(data.success){
			console.log(data["systemEntityVo"]);
			systemEntityVo = JSON.parse(data["systemEntityVo"]);
			setTableSelection(entityName);
		} else{
			alertErrorMessage("Exception : " + data.message + ".");
		}
	});
}

function clearGrid(gridId){
	form.getGridById(gridId).loadRows([], false);
}

function isBefore(date1, date2) {
    return new Date(date1) < new Date(date2); // true if time1 is later
}

function setTableSelection(entityName){
	var tableNames = getTableNames(entityName, systemEntityVo);
	removeOptionExceptFirst(['#tableSelection', '#fieldSelection', '#operatorSelection']);
	$.each(tableNames, function (i, tableName) {
	    $('#tableSelection').append($('<option>', { 
	        value: tableName,
	        text : tableName 
	    }));
	});
}

//Handler for Table Name Selection
function tableChange(){
	var tableSelected = $("#tableSelection option:selected" ).text()
	setColumnSelection(tableSelected);
}

function setColumnSelection(tableName){
	console.log("-->" + tableName)
	var columns = getColumns(tableName, systemEntityVo);
	removeFilterValueDatePicker();
	clearTextInput(['#filterText']);
	removeOptionExceptFirst(['#fieldSelection', '#operatorSelection']);
	$.each(columns, function (i, column) {
	    $('#fieldSelection').append($('<option>', { 
	        value : column.datatype,
	        text : column.name 
	    }));
	});
}

//Handler for Field Name Selection
function fieldChange(){
	var datatype = $("#fieldSelection option:selected").val();
	setOperatorSelection(datatype);
}

function removeFilterValueDatePicker(){
	destroyDatePicker('#filterValue');
}

function destroyDatePicker(selector){
	$(selector).datepicker("destroy")
}

function setDatePicker(selector){
	$(selector).datepicker({
		dateFormat:mjQueryDtFormat,
		changeYear:true,
		changeMonth:true,
		showOn: 'both',
		 buttonImage: 'images/calendar_2.gif',
		 buttonImageOnly: true
    });
}

function filterValueDatePickerEnabler(datatype){
	var selector = '#filterText';
	if(datatype == 'DATE') 	{
		setDatePicker(selector);
		$(selector).attr("readonly", "true");
	}
	else {
		destroyDatePicker(selector);
		$(selector).removeAttr("readonly");
//		$("").attr("readonly", "false");
	}
}

function validateValueByDatatype(value, datatype){
//	alertErrorMessage("Value: " + value + ", Datatype: " + datatype);
	if(datatype == 'NUMBER'){
		if(!parseInt(value)) {
			alertErrorMessage("Enter a numeric value");
			return false;
		}
	}
	
	return true;
}

function setOperatorSelection(datatype){
	var operators = getOperators(datatype);
	clearTextInput(['#filterText']);
	filterValueDatePickerEnabler(datatype);
	removeOptionExceptFirst(["#operatorSelection"]);
	$.each(operators, function (i, operator) {
	    $('#operatorSelection').append($('<option>', { 
	        value : operator,
	        text : operator
	    }));
	});
}

//Utility Functions for System Entity Vo
function getColumnNames(tableName){
	var columnNamesArr = [];
	var columns = getColumns(tableName, systemEntityVo);
	for(var prop in columns)
		if(columns.hasOwnProperty(prop))
			columnNamesArr.push(columns[prop].name);

	return columnNamesArr;
}

function getTableNames(entityName, entityVo){
	var tableNamesArr = [];
	var tables = getTables(entityName, entityVo);
	for(var prop in tables)
		if(tables.hasOwnProperty(prop))
			tableNamesArr.push(tables[prop].name);

	return tableNamesArr;
}

function getTables(entityName, entityVo){
	var arr = [];
	if(entityVo['entityName'] == entityName){
		var table = entityVo['parentTable'];
		arr = arr.concat(getChildTables(table));
		return arr;
	} else {
		var entityVos = entityVo['childrenEntities'];
		for(var index in entityVos)
			if(entityVos.hasOwnProperty(index))
				return getTables(entityName, entityVos[index]);
	}
}

function getColumns(tableName, entityVo){
	var parentTable = entityVo['parentTable'];
	if(parentTable.name == tableName){
		return parentTable['columns'];
	} 
	var childrenTables = parentTable['children'];
	for(var index in childrenTables){
		if(childrenTables.hasOwnProperty(index)){
			var childTable = childrenTables[index];
			if(childTable.name == tableName){
				return childTable['columns'];
			} 
		}
	}
	var entityVos = entityVo['childrenEntities'];
	for(var index in entityVos){
		if(entityVos.hasOwnProperty(index)){
			return getColumns(tableName, entityVos[index]);
		}
	}
}

function getChildTables(table){
	var tables = [];
	tables.push(table);
	for(var index in table['children']){
		if(table['children'].hasOwnProperty(index))
			tables = tables.concat(getChildTables(table['children'][index]));
	}
	return tables;
}

function getParentTable(entityName, entityVo){
    if(entityVo['entityName'] == entityName)
    	return entityVo['parentTable'];
	else 
    	for(var index in entityVo['childrenEntities']){
    		return getParentTable(entityName, entityVo['childrenEntities'][index]);
    	}
}

//Utility functions
function removeOptionExceptFirst(selectors){
	for(var index in selectors)
		if(selectors.hasOwnProperty(index))
			$(selectors[index]).find('option').not(':first').remove();
}

function clearTextInput(selectors){
	for(var index in selectors)
		if(selectors.hasOwnProperty(index))
			$(selectors[index]).val("");
}

function getOperators(datatype){
	return datatypeOperatorMap[datatype];
}

function setGridFieldValues(){
	var braceSelection = $("#openingBraceSelection option:selected").val();
	$('#openBrace').val(braceSelection == 'NA' ? '' : braceSelection);
	$('#tableName').val($("#tableSelection option:selected").text());
	$('#fieldName').val($("#fieldSelection option:selected").text());
	$('#filterOperator').val($("#operatorSelection option:selected").text());
	$('#filterValue').val($("#filterText").val());
	braceSelection = $("#closingBraceSelection option:selected").val();
	$('#closeBrace').val(braceSelection == 'NA' ? '' : braceSelection);
}

function addGridFields(grid, arr){
	for(var index in arr){
		if(arr.hasOwnProperty(index)){
			var obj = arr[index];
			var gridField = form.getFieldById(obj.id);
			gridField.setIsGridField(true);
			gridField.setGridListIndex(obj.index);
			gridField.setLabel(obj.label);
			grid.addField(gridField);
		}
	}
}

function doSearch(){
	var gridId = getGridId(wfaction, status);
	console.log("gridId: " + gridId)
	var grid1 = gridDetailsArray[gridId];
	//searchCriteria = new Array();
	var searchJSONString = JSON.stringify(getSearchCriteria());
	grid1.setSearchCrt(searchJSONString);
	grid1.setDiv('resultGrid');
	grid1.setShowHeader(true);
	grid1.setShowFrame(true);
	grid1.setHeight(300);
	if(!(isMakerUnauthView() || isMakerAuthView() || isCheckerUnauthView() || isCheckerAuthView())){
		var selectionConfig = new Object();
		selectionConfig.selectionType = 'checkbox';
		selectionConfig.selectionHandler = populateSelectedList;
		grid1.setSelectionModel(selectionConfig);
	}
	grid1.createGrid();
	
	displayBottomPanelButton();
	
	function getGridId(){
		//alert('isMakerUnauthView(): ' + isMakerUnauthView());
		status = $('#status').val();
		if(wfaction == 'authReject'){
			return 8001;
		} else if (wfaction == 'modifyDelete'){
			if(status == 'unauth') return 8002;
			if(status == 'auth') return 8003;
		} else if (isMakerUnauthView()){
			return 8002;
		} else if (isMakerAuthView()){
			return 8003;
		} else if (isCheckerUnauthView()){
			return 8002;
		} else if (isCheckerAuthView()){
			return 8003;
		}
	}

	
	function getSearchCriteria(){
		var searchCriteria = new Array();
		
		addToCriteria($("#archivalName").val(), "NAME", "LIKE", searchCriteria);
		addToCriteria($("#datasource").val(), "DATASOURCE", "=", searchCriteria);
		addToCriteria(getDateInOracleFormat($("#effectiveDate").val()), "EFFECTIVE_DATE", "=", searchCriteria);
		addToCriteria(getDateInOracleFormat($("#expiryDate").val()), "EXPIRY_DATE", "=", searchCriteria);
		
		searchCriteria.push({"name" : "IS_ARCHIVE", "operator" : "=", "value" : isArchive});
		console.dir(searchCriteria);
		return searchCriteria;
		
		function getDateInOracleFormat(val){
			if(val == "") return "";
			val = val.split("/");
			var date = val[0];
			var month = val[1];
			var year = val[2];
			console.log(date + "-" + monName[parseInt(month, 10) - 1] + "-" + year);
			return date + "-" + monName[parseInt(month, 10) - 1] + "-" + year;
		}
		
		function addToCriteria(val, dbColumn, operator, searchCriteria){
			if(val != "")
				searchCriteria.push({"name" : dbColumn, "operator" : operator, "value" : val});
		}
	}

	function displayBottomPanelButton(){
		if(wfaction == 'authReject'){
			document.getElementById('checkerAuthorize').style.display = "block";
		} else if (wfaction == 'modifyDelete'){
			document.getElementById('makerModify').style.display = "block";
		} else if (wfaction == 'checkersearch_frame'){
			document.getElementById('checkerUnauthView').style.display = "block";
		}
	}
}

function doAuthorize(){
	var archivalDefinitionArray = new Array();
	if (gridSelectedRecords && gridSelectedRecords.length>0) {
		for ( var key in gridSelectedRecords) {
			if (gridSelectedRecords.hasOwnProperty(key)) {
				var record = gridSelectedRecords[key];
				var reqId = record['reqid'];
				var s = record['chkbox'].split("#");
				var id = parseInt(s[2]);
				var action = s[1];
				var archivalDefinitionEntity = new Object();
				archivalDefinitionEntity.checkerId = user;
				archivalDefinitionEntity.action = action;
				archivalDefinitionEntity.id = id;
				archivalDefinitionEntity.status = 'unauth';
				archivalDefinitionEntity.reqId = reqId;
				archivalDefinitionArray.push({
					"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity",
					"dbOperation" : 'authorize',
					"entityData" : archivalDefinitionEntity
				});
			}
		}
	}else {
		alertErrorMessage("Select Records to authorize");
		return false;
	}
	var jsonData = new Object();
	jsonData.data = JSON.stringify(archivalDefinitionArray);
//
	var jsonInvokeInfo = {"ajaxMethod":"authorizeArchivalEntity", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore" };
	alertErrorMessage(jsonInvokeInfo);
	GenericDwr.invokeMethod(jsonInvokeInfo, jsonData, function(data) {
		if (data.success) {
			doSearch();
		} else {
			alertErrorMessage("Exception : " + data.message+ ".");
		}
	});

}

function populateSelectedList(selectedObjs){
	gridSelectedRecords = [];
	for(var key in selectedObjs){
		if (selectedObjs.hasOwnProperty(key)) {
			gridSelectedRecords.push(selectedObjs[key].data);
		}
	}
	console.dir(gridSelectedRecords);
}

function display(obj){
	for (var key in obj) 
		if (obj.hasOwnProperty(key)) 
			console.log(key + ' - ' + obj[key]);
}

function getGridData(gridId){
	return form.getGridById(gridId).getAllRows();
}

function validation(){
	return (validateEffectiveDateBeforeExpiryDate() && validateOpenCloseBraces() && validateMandatoryFields());
	
	function validateMandatoryFields(){
		if(!form.validateForm()){
			return false;
		}
		if(!isOptionSelected('datasource', 'NA')){
			extMessageAlert('Error', 'Please Select Datasource', false, form.getFieldById('datasource'));
			return false;
		}
		if(!isOptionSelected('entityName', 'NA')){
			extMessageAlert('Error', 'Please Select Entity', false, form.getFieldById('entityName'));
			return false;
		}
		
		if(getGridData('archivalEntityRuleGrid').length == 0){
			alertErrorMessage('Please Add Rules for Selected Entity');
			return false;
		}
		return true;
	}	
	
	function validateOpenCloseBraces(){
		var gridDataArray = getGridData('archivalEntityRuleGrid');
		var openBraceString = "";
		var closeBraceString = "";
		
		for(var index in gridDataArray){
			var gridRowData = gridDataArray[index];
			if(gridRowData['openBrace'])
				openBraceString += gridRowData['openBrace'];
			if(gridRowData['closeBrace'])
				closeBraceString += gridRowData['closeBrace'];
		}
		alert("Open: " + countCharacter(openBraceString, "(") != countCharacter(closeBraceString, ")"));
		if(countCharacter(openBraceString, "(") != countCharacter(closeBraceString, ")")){
			alertErrorMessage("Opening Braces must match Closing Brace");
			return false;
		}
		return true;
		
		function countCharacter(str, char){
		    for(var i=count=0; i<str.length; count+=+(char==str[i++]));
		    	return count;
		}
	}
	
	function validateEffectiveDateBeforeExpiryDate(){
		var effectiveDate = $('#effectiveDate').val();
		var expiryDate = $('#expiryDate').val();
		alert("isBefore(expiryDate, effectiveDate): " + isBefore(expiryDate, effectiveDate));
		if(isBefore(expiryDate, effectiveDate)){
			alertErrorMessage("Expiry date must come after Effective Date");
			return false;
		}
		return true;
//		alertErrorMessage("Effective Date: " + effectiveDate + ", Expiry Date: " + expiryDate);
//		alertErrorMessage("Effective Date before Expiry Date: " + isBefore(effectiveDate, expiryDate));
	}
}

function alertErrorMessage(msg){
	extMessageAlert('Error', msg, false);
}

function readonly(selector){
	$(selector).prop("readonly", true);
}

function loadUnauthorizedRecord(reqId){
	var entityData = getUnauthorizedEntityData(reqId);
}

function loadEntityData(entityData){
	loadEntityName();
	form.loadData(entityData);
	createRuleGrid(entityData.archivalEntityRuleGrid);
	populateSystemEntityVo();
}

function loadAuthorizedRecord(archivalName, archivalId){
	var data = {};
	data["name"] = archivalName;
	data["id"] = parseInt(archivalId);
	//alert("archivalId: " + archivalId);
	var vFormRecord = {"entityName" : "com.polaris.workflow.archive.entity.ArchivalDefinitionEntity", "dbOperation" : "save", "entityData" : data};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"getAuthorizedRecord", "ajaxClass":"com.polaris.workflow.store.ArchivalPurgingDefinitionStore"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,function(data){
		if(data.success){
//			wfAlert("Msg: " + data.message);
//			console.dir(data);
			var entityData = JSON.parse(data.data);
//			console.dir(entityData);
			var gridData = JSON.parse(entityData.archivalEntityRuleGrid);
//			entityData.archivalEntityRuleGrid = JSON.parse(entityData.archivalEntityRuleGrid);
//			console.dir(gridData);
			loadEntityName();
			form.loadData(entityData);
			createRuleGrid(gridData);
			populateSystemEntityVo();
		} else{
			alertErrorMessage("Error : " + data.message + ".");
		}
	});
	
}

function isMakerNew(){
	var screenDetail = getScreenDetail();
	return (screenDetail.wfaction == "new")
}

function isMakerAuthModify(){
	var screenDetail = getScreenDetail();
	return (screenDetail.wfaction == "modifyDelete" && screenDetail.status == "auth");
}

function isMakerUnauthView(){
	return (wfaction == "makersearch_frame" && status == "unauth");
}

function isMakerUnauthModify(){
	var screenDetail = getScreenDetail();
	return (screenDetail.wfaction == "modifyDelete" && screenDetail.status == "unauth");
}

function isCheckerUnauthView(){
	return (wfaction == "checkersearch_frame" && status == "unauth");
}


function isMakerAuthView(){
	return (wfaction == "makersearch_frame" && status == "auth");
}

function isCheckerAuthorize(){
	return (wfaction == "authReject")
}

function isCheckerAuthView(){
	return (wfaction == "checkersearch_frame" && status == "auth");
}

function getScreenDetail(){
	return {
		"wfaction": wfaction,
		"archivalName":archivalName,
		"archivalId" : archivalId,
		"status" : status
	};
}

function displayScreenDetails(){
	console.log("---Screen Details---");
	console.dir(getScreenDetail());
	console.log("isMakerNew - " + isMakerNew());
	console.log("isMakerAuthModify - " + isMakerAuthModify());
}

function doClose(){
	window.opener.doSearch();
	self.close();
}

function doClear(){
	form.clearFormFields();
}
//extMessageAlert('Error', fieldLabel + ' cannot be more than ' + length + ' characters.', false, fieldObj)