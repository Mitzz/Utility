alert("APSchedulerDelink.js")

var gridSelectedRecords = [];
var monName=new Array("JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC");

function init(){
//	loadEntityName();
//	initializeDatePicker();
}

/*function loadEntityName(){
	alert("Entity Nam");
	var entityDropDown=form.getFieldById('entityName');
	console.dir(entityDropDown);
	entityDropDown.setQueryCode('ARCHIVAL_ENTITY');
	entityDropDown.loadData();
//	console.dir(getUnuthorizedEntityData(1228));
}*/

function initializeDatePicker(){
	
	$("#effectiveDate, #expiryDate").datepicker({
		dateFormat:"dd/mm/yy",
		changeYear:true,
		changeMonth:true,
		showOn: 'both',
		buttonImage: 'images/calendar_2.gif',
		buttonImageOnly: true
    });
}

function doSearch(){
	var gridId = getGridId();
	console.log("gridId: " + gridId)
	var grid1 = gridDetailsArray[gridId];
	var searchJSONString = JSON.stringify(getSearchCriteria());
	grid1.setSearchCrt(searchJSONString);
	grid1.setDiv('resultGrid');
	grid1.setShowHeader(true);
	grid1.setShowFrame(true);
	grid1.setHeight(300);
	if(isArchive == "Y" || isArchive == "N"){
		var selectionConfig = new Object();
		selectionConfig.selectionType = 'checkbox';
		selectionConfig.selectionHandler = gridSelectionHandler;
		grid1.setSelectionModel(selectionConfig);
	}
	grid1.createGrid();
	display(['delink_div']);
		
	function getGridId(){
		if(isArchive == "Y" || isArchive == "N") return 8007;
	}
	
	function getSearchCriteria(){
		//SELECT SCH.SCHEDULER_NAME as SCHEDULER_NAME, SCH.SCHEDULER_TYPE as SCHEDULER_TYPE, APDEF.NAME as AP_NAME, APDEF.DATASOURCE as AP_DATASOURCE, MAP.ID as MAPPING_ID FROM PH_SCHEDULER_MASTER SCH, AP_ARCH_PURGE_DEF APDEF, AP_ARCH_PURGE_MAPPING MAP WHERE SCH.SCHEDULER_ID = MAP.SCHEDULER_ID AND APDEF.ID = MAP.AP_DEFINITION_ID AND MAP.ISACTIVE = 'Y'
		var searchCriteria = new Array();
		addToCriteria($("#schedulerName").val(), "SCH.SCHEDULER_NAME", "LIKE", searchCriteria);
		addToCriteria($("#apName").val(), "APDEF.NAME", "LIKE", searchCriteria);
		addToCriteria($("#apDatasource").val() , "APDEF.DATASOURCE", "=", searchCriteria);
		
		searchCriteria.push({"name" : "IS_ARCHIVE", "operator" : "=", "value" : isArchive});
		console.dir(searchCriteria);
		return searchCriteria;
		
		//dd-MON-yyyy
		function getDateInOracleFormat(val){
			if(val == "") return "";
			val = val.split("/");
			var date = val[0];
			var month = val[1];
			var year = val[2];
			console.log(date + "-" + monName[parseInt(month, 10) - 1] + "-" + year);
			return date + "-" + monName[parseInt(month, 10) - 1] + "-" + year;
		}
		
		function addToCriteria(val, dbColumn, operator, searchCriteria){
			if(val && val != "")
				searchCriteria.push({"name" : dbColumn, "operator" : operator, "value" : val});
		}
	}

}

function display(idSelectors){
	for(var prop in idSelectors){
		if(idSelectors.hasOwnProperty(prop)){
			var idSelector = idSelectors[prop];
			document.getElementById(idSelector).style.display = "block";
		}
	}
	
}

function gridSelectionHandler(selectedObjs){
	gridSelectedRecords = [];
	for(var key in selectedObjs){
		if (selectedObjs.hasOwnProperty(key)) {
			gridSelectedRecords.push(selectedObjs[key].data);
		}
	}
	//console.dir(gridSelectedRecords);
}

function doClear(){
	reset(["#apDatasource", "#apName", "#schedulerType", "#schedulerName"]);
}

function reset(selectors){
	for(var prop in selectors){
		if(selectors.hasOwnProperty(prop)){
			var selector = selectors[prop];
			var el = $(selector);
			if(el.is('input')) { //we are dealing with an input
				$(selector).val("");
			} else if(el.is('select')) { //we are dealing with a select
				setFirstOption(selector);
			} else { //we are dealing with a textarea
				console.log("reset field: unknown");
			}
		}
	}
}

function setFirstOption(selector){
	$(selector).val($(selector + " option:first").val());
}

function doSchedule(){
	for(var key in gridSelectedRecords){
		if (gridSelectedRecords.hasOwnProperty(key)) {
			var gridRecord = gridSelectedRecords[key];
			console.dir(gridRecord);
		}
	}
	if(gridSelectedRecords.length == 0) {
		alert("Select Record to Archive");
		return;
	}
	window.open("ArchivalSchedule.jsp?isArchive="+isArchive,"","alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60");
}

function doDelink(){
	if(!isAnyGridRecordSelected()){
		return;
	}
	var formData = getEntityData();
	var vFormRecord = {"entityData" : formData};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"delink", "ajaxClass":"com.polaris.workflow.store.APSchedulerMappingStore"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,function(data){
		if(data.success){
			wfAlert( data.message);
			doClear();
			doSearch();
		} else{
			wfAlert("Exception : " + data.message + ".");
		}
	});
}

function getEntityData(){
	var mappingIdArray = getSelectedMappingId();
	var entityData = {};
	var entityDataArray = [];
	for(var prop in mappingIdArray){
		if(mappingIdArray.hasOwnProperty(prop)){
			entityData["id"] = parseInt(mappingIdArray[prop]);
			entityDataArray.push(entityData);
			entityData = {};
		}
	}
	return entityDataArray;
}

function getSelectedMappingId(){
	var mappingIdArray = [];
	for(var key in gridSelectedRecords){
		if (gridSelectedRecords.hasOwnProperty(key)) {
			var gridRecord = gridSelectedRecords[key];
			mappingIdArray.push(gridRecord["mapping_id"]);
		}
	}
	return mappingIdArray;
}

function isAnyGridRecordSelected(){
	if(gridSelectedRecords.length == 0) {
		alert("Select Grid Records");
		return false;
	}
	return true;
}

function doClose(){
	self.close();
}

/*function doSave(){
	if(gridSelectedRecords.length == 0) {
		alert("Select Scheduler");
		return;
	}
	var schedulerIdArray = [];
	for(var key in gridSelectedRecords){
		if (gridSelectedRecords.hasOwnProperty(key)) {
			var gridRecord = gridSelectedRecords[key];
			schedulerIdArray.push(gridRecord["scheduler_id"]);
		}
	}
	var archivalName = $("#archivalName").val();
	var archivalIdArray = $("#archivalId").val().split(",");
	
//	console.log("Scheduler Id: " + schedulerIdArray + ", Archival Name: " + archivalName + ", Archival Id: " + archivalId);

//	private long apDefinitionId;
	
//	@ColumnInfo(columnName = "SCHEDULER_ID")
//	private long schedulerId;

	var entityData = {};
	var entityDataArray = [];
	for(var index in schedulerIdArray){
		if(schedulerIdArray.hasOwnProperty(index)){
			for(var ind in archivalIdArray){
				if(archivalIdArray.hasOwnProperty(ind)){
					entityData["schedulerId"] = parseInt(schedulerIdArray[index], 10);
					entityData["apDefinitionId"] = parseInt(archivalIdArray[ind], 10);
					entityData["status"] = "auth";
					entityData["action"] = "new";
					//entityData["isActive"] = "Y";
					entityDataArray.push(entityData); 
					entityData = {};
				}
			}
 		}
	}
	
	
	console.dir(entityDataArray);
	
	var formData = entityDataArray;
	var vFormRecord = {"entityName" : "com.polaris.workflow.archive.entity.APSchedulerMappingEntity", "dbOperation" : "save", "entityData" : formData};
	var jsonData = new Object();
	jsonData.data = JSON.stringify(vFormRecord);
	var jsonInvokeInfo = {"ajaxMethod":"insert", "ajaxClass":"com.polaris.workflow.store.APSchedulerMappingStore"};
	
	GenericDwr.invokeMethod(jsonInvokeInfo,jsonData,function(data){
		if(data.success){
			wfAlert( data.message);
		} else{
			wfAlert("Exception : " + data.message + ".");
		}
	});
	
	return;
}*/