/*******************************************************************/
/*    Copyright  2013 Polaris Software Lab Ltd                      */
/*                                                                 */
/*  All rights reserved. These materials are confidential and      */
/*  proprietary to Polaris Software Lab Ltd and no part of these     */
/*  materials should be reproduced, published, transmitted or      */
/*  distributed  in any form or by any means, electronic,          */
/*  mechanical, photocopying, recording or otherwise, or stored in */
/*  any information storage or retrieval system of any nature nor  */
/*  should the materials be disclosed to third parties without the */
/*  prior express written authorization of Polaris Software Lab Ltd. */
/*                                                                 */
/*******************************************************************/

/*******************************************************************
*
* File Name           :DataBaseInfo.java
*
* Description         :This is the custom annotation definition class for class level annotation.  
*
*            Version Control Block
*
* Date        	Version         Author                  Description
* ---------   	-------  	-------------  		------------
* 20/05/2013 	1.0   		Jitin Chouhan		New file
********************************************************************/
package com.polaris.genericmaint.annotation.definition;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
	public @interface Table{
		public String tableName();
	}
