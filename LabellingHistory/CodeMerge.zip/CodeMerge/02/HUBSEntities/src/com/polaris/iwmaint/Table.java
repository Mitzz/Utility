/*******************************************************************/
/*    Copyright�  2013 Polaris Software Lab Ltd                      */
/*                                                                 */
/*  All rights reserved. These materials are confidential and      */
/*  proprietary to Polaris Software Lab Ltd and no part of these     */
/*  materials should be reproduced, published, transmitted or      */
/*  distributed  in any form or by any means, electronic,          */
/*  mechanical, photocopying, recording or otherwise, or stored in */
/*  any information storage or retrieval system of any nature nor  */
/*  should the materials be disclosed to third parties without the */
/*  prior express written authorization of Polaris Software Lab Ltd. */
/*                                                                 */
/*******************************************************************/

/**********************************************************************
 *
 * Module Name         :
 *
 * File Name           :Table.java
 *
 * Description         :This file contains Actual marhsalling and unmarshalling for Screen
 *
 *           Copyright (c) 2013 Polaris Software Lab Ltd
 *
 *            Version Control Block
 *
 * Date        Version     Author               Description
 * ---------   --------  ---------------  ---------------------------
 * 10/12/2013	1.0			Kuldeep Keshwar		New File 
 * 15/07/2014	1.1			Naveenprasad M		For JS API enhancement(CODE & LOAD_RULE_ID attributes added)
 * 04/09/2015	1.2			Krishna Reddy		Changes related to Internationalization
**********************************************************************/
package com.polaris.iwmaint;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.google.gson.annotations.Expose;

@XmlRootElement(name="TABLE")
@XmlAccessorType(XmlAccessType.FIELD)
public class Table extends AbstractBlock {

	@Expose @XmlAttribute (name="CODE")
	private String CODE;
	
	@Expose @XmlAttribute (name="LOAD_RULE_ID")
	private String LOAD_RULE_ID;

	@Expose @XmlAttribute (name="GRIDPOS")
	private String GRIDPOS;
	
	@Expose @XmlAttribute (name="ISPAGING")
	private String ISPAGING;
	
	@Expose @XmlAttribute (name="PAGESIZE")
	private String PAGESIZE;
	
	@Expose @XmlAttribute (name="DISPCOLS")
	private String DISPCOLS;
	
	@Expose @XmlAttribute (name="DISPROWS")
	private String DISPROWS;
	
	@Expose @XmlAttribute (name="NO_OF_ROWS")
	private String NO_OF_ROWS;
	
	//@Expose @XmlAttribute (name="COND_NAME")
	private String COND_NAME = "";
	
	//@Expose @XmlAttribute (name="ACTION")
	private String ACTION = "";
	
	@Expose @XmlAttribute (name="NATIVE")
	private String NATIVE = "Y";
	
	@Expose @XmlElement (name="ERROR_TEXT",type = Header.class)
	private Header ERROR_TEXT;
	
	@Expose @XmlElement(name="TR",type = Tr.class) 
	private List<Tr> Tr;
	@Expose @XmlElement  (name="UIC",type = Uic.class)
	private Uic UIC;

	public Table() {
		this.Tr = new ArrayList<Tr>();
	}

	public String getGRIDPOS() {
		return GRIDPOS;
	}

	public void setGRIDPOS(String gRIDPOS) {
		GRIDPOS = gRIDPOS;
	}

	public String getISPAGING() {
		return ISPAGING;
	}

	public void setISPAGING(String iSPAGING) {
		ISPAGING = iSPAGING;
	}
	
	public String getPAGESIZE() {
		return PAGESIZE;
	}

	public void setPAGESIZE(String pAGESIZE) {
		PAGESIZE = pAGESIZE;
	}

	public String getDISPCOLS() {
		return DISPCOLS;
	}

	public void setDISPCOLS(String dISPCOLS) {
		DISPCOLS = dISPCOLS;
	}

	public String getDISPROWS() {
		return DISPROWS;
	}

	public void setDISPROWS(String dISPROWS) {
		DISPROWS = dISPROWS;
	}

	public String getNO_OF_ROWS() {
		return NO_OF_ROWS;
	}

	public void setNO_OF_ROWS(String nO_OF_ROWS) {
		NO_OF_ROWS = nO_OF_ROWS;
	}

	public String getCOND_NAME() {
		return COND_NAME;
	}

	public void setCOND_NAME(String cOND_NAME) {
		COND_NAME = cOND_NAME;
	}

	public String getACTION() {
		return ACTION;
	}

	public void setACTION(String aCTION) {
		ACTION = aCTION;
	}

	public String getNATIVE() {
		return NATIVE;
	}

	public void setNATIVE(String nATIVE) {
		NATIVE = nATIVE;
	}

	public List<Tr> getTr() {
		return Tr;
	}

	public void setTr(List<Tr> tr) {
		Tr = tr;
	}

	public Uic getUIC() {
		return UIC;
	}

	public void setUIC(Uic uIC) {
		UIC = uIC;
	}

	public String getCODE() {
		return CODE;
	}

	public void setCODE(String cODE) {
		CODE = cODE;
	}

	public String getLOAD_RULE_ID() {
		return LOAD_RULE_ID;
	}

	public void setLOAD_RULE_ID(String lOAD_RULE_ID) {
		LOAD_RULE_ID = lOAD_RULE_ID;
	}

	public Header getERROR_TEXT() {
		return ERROR_TEXT;
	}

	public void setERROR_TEXT(Header eRROR_TEXT) {
		ERROR_TEXT = eRROR_TEXT;
	}
	// 1.2 starts
	@Expose @XmlAttribute(name="colSpan")
	private Integer colSpan;
	@Expose @XmlAttribute(name="HEADER_BACKGROUND")
	private String HEADER_BACKGROUND;
	@Expose @XmlAttribute(name="DEFVIEW")
	private String DEFVIEW;
	@Expose @XmlAttribute(name="HIDEHEADER")
	private String HIDEHEADER;
	
	public Integer getColSpan() {
		return colSpan;
	}
	public void setColSpan(Integer colSpan) {
		this.colSpan = colSpan;
	}
	public String getHEADER_BACKGROUND() {
		return HEADER_BACKGROUND;
	}
	public void setHEADER_BACKGROUND(String hEADER_BACKGROUND) {
		HEADER_BACKGROUND = hEADER_BACKGROUND;
	}
	public String getDEFVIEW() {
		return DEFVIEW;
	}
	public void setDEFVIEW(String dEFVIEW) {
		DEFVIEW = dEFVIEW;
	}
	public String getHIDEHEADER() {
		return HIDEHEADER;
	}
	public void setHIDEHEADER(String hIDEHEADER) {
		HIDEHEADER = hIDEHEADER;
	}
	// 1.2 ends
	
}