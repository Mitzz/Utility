package com.polaris.iwapp.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;

public class Table implements Serializable{

	@Expose private List<String> fieldIds = new ArrayList<String>();	
	@Expose private String defView = "E";
	@Expose private boolean isGrid = false;
	@Expose private String gridId;	
	@Expose private List<String> ruleIds  = new ArrayList<String>();
	@Expose private String uicId;
	@Expose private int tableSeqNo = 1;
	
	public List<String> getFieldIds() {
		return fieldIds;
	}
	public void setFieldIds(List<String> fieldIds) {
		this.fieldIds = fieldIds;
	}
	public String getDefView() {
		return defView;
	}
	public void setDefView(String defView) {
		this.defView = defView;
	}
	public boolean isGrid() {
		return isGrid;
	}
	public void setGrid(boolean isGrid) {
		this.isGrid = isGrid;
	}
	public String getGridId() {
		return gridId;
	}
	public void setGridId(String gridId) {
		this.gridId = gridId;
	}
	public List<String> getRuleIds() {
		return ruleIds;
	}
	public void setRuleIds(List<String> ruleIds) {
		this.ruleIds = ruleIds;
	}
	public String getUicId() {
		return uicId;
	}
	public void setUicId(String uicId) {
		this.uicId = uicId;
	}
	public int getTableSeqNo() {
		return tableSeqNo;
	}
	public void setTableSeqNo(int tableSeqNo) {
		this.tableSeqNo = tableSeqNo;
	}
}
