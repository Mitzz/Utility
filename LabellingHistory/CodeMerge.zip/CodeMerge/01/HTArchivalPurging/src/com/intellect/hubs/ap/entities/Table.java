package com.intellect.hubs.ap.entities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Table {

	private String name;
	private Set<Table> children = new HashSet<Table>();
	private Set<Column> columns = new HashSet<Column>();
	private List<EntityLinkToParent> childTableLinks = new ArrayList<EntityLinkToParent>();
	
	public Set<Table> getChildren() {
		return children;
	}
	public void setChildren(Set<Table> children) {
		this.children = children;
	}
	public Set<Column> getColumns() {
		return columns;
	}
	public void setColumns(Set<Column> columns) {
		this.columns = columns;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<EntityLinkToParent> getChildTableLinks() {
		return childTableLinks;
	}
	public void setChildTableLinks(List<EntityLinkToParent> childTableLinks) {
		this.childTableLinks = childTableLinks;
	}
	@Override
	public String toString() {
		return "Table [name=" + name + ", children (" + (children == null ? 0 : children.size()) +")=" + (children == null ? "null" : children) + ", columns="
				+ columns + ", childTableLinks" +  childTableLinks + "]";
	}
	
	
}
