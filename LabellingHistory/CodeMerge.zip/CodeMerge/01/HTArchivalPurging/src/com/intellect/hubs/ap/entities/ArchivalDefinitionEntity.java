package com.intellect.hubs.ap.entities;

import java.sql.Date;

import com.polaris.genericmaint.annotation.definition.CDate;
import com.polaris.genericmaint.annotation.definition.ColumnInfo;
import com.polaris.genericmaint.annotation.definition.PrimaryKey;
import com.polaris.genericmaint.annotation.definition.Table;
import com.polaris.genericmaint.entityBeans.Entity;


@Table(tableName = "AP_ARCH_PURGE_DEF")
public class ArchivalDefinitionEntity extends Entity{

	@PrimaryKey
	@ColumnInfo(columnName = "ID")
	private int id;
	
	@ColumnInfo(columnName = "NAME")
	private String name;
	
	@ColumnInfo(columnName = "IS_ARCHIVE")
	private String isArchive;
	
	@ColumnInfo(columnName = "DATASOURCE")
	private String datasource;
	
	@CDate(dateType = "java.sql.Date", format = "dd/MM/yyyy")
	@ColumnInfo(columnName = "EFFECTIVE_DATE")
	private Date effectiveDate;
	
	@CDate(dateType = "java.sql.Date", format = "dd/MM/yyyy")
	@ColumnInfo(columnName = "EXPIRY_DATE")
	private Date expiryDate;
	
	@ColumnInfo(columnName = "ENTITY_NAME")
	private String entityName;
	
	@ColumnInfo(columnName = "PRE_HOOK")
	private String preHook;
	
	@ColumnInfo(columnName = "POST_HOOK")
	private String postHook;
	
	
	private String archivalEntityRuleGrid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsArchive() {
		return isArchive;
	}

	public void setIsArchive(String isArchive) {
		this.isArchive = isArchive;
	}

	public String getDatasource() {
		return datasource;
	}

	public void setDatasource(String datasource) {
		this.datasource = datasource;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getPreHook() {
		return preHook;
	}

	public void setPreHook(String preHook) {
		this.preHook = preHook;
	}

	public String getPostHook() {
		return postHook;
	}

	public void setPostHook(String postHook) {
		this.postHook = postHook;
	}

	public String getArchivalEntityRuleGrid() {
		return archivalEntityRuleGrid;
	}

	public void setArchivalEntityRuleGrid(String archivalEntityRuleGrid) {
		this.archivalEntityRuleGrid = archivalEntityRuleGrid;
	}

	
}
