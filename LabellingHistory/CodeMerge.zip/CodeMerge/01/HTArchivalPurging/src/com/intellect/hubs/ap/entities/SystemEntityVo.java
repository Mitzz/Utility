package com.intellect.hubs.ap.entities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SystemEntityVo {

	private String entityName;
	private SystemEntityVo parentEntity;
	private Table parentTable;
	private Set<SystemEntityVo> childrenEntities = new HashSet<SystemEntityVo>();
	
	private List<EntityLinkToParent> relationToParent = new ArrayList<EntityLinkToParent>();

	public List<EntityLinkToParent> getRelationToParent() {
		return relationToParent;
	}

	public void setRelationToParent(List<EntityLinkToParent> relationToParent) {
		this.relationToParent = relationToParent;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public SystemEntityVo getParentEntity() {
		return parentEntity;
	}

	public void setParentEntity(SystemEntityVo parentEntity) {
		this.parentEntity = parentEntity;
	}

	public Table getParentTable() {
		return parentTable;
	}

	public void setParentTable(Table parentTable) {
		this.parentTable = parentTable;
	}

	public Set<SystemEntityVo> getChildrenEntities() {
		return childrenEntities;
	}

	public void setChildrenEntities(Set<SystemEntityVo> childrenEntities) {
		this.childrenEntities = childrenEntities;
	}
	
	public void addChildrenEntity(SystemEntityVo childEntity) {
		this.childrenEntities.add(childEntity);
		childEntity.setParentEntity(this);
	}

	@Override
	public String toString() {
		return "SystemEntityVo [entityName=" + entityName + ", parentTable=" + parentTable + ", relationToParent=" + relationToParent + "]";
	}

	
	
	
}
