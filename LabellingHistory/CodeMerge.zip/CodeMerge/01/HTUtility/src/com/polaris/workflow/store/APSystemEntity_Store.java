package com.polaris.workflow.store;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.intellect.hubs.ap.entities.SystemEntityVo;
import com.polaris.genericmaint.store.GenericStore;
import com.polaris.labelling.utility.LabelCache;
import com.polaris.workflow.tools.WFLogger;

public class APSystemEntity_Store extends GenericStore{
	private static WFLogger logger = WFLogger.getInstance((APSystemEntity_Store.class).getName());
	
	public APSystemEntity_Store(){
		
	}
	
	public Map getSystemEntityVo(Map<String, String> data) throws SQLException, Exception
	{
		System.out.println(data);
		JSONObject jsonObject = new JSONObject(data.get("data"));
		SystemEntityVo systemEntityVo = LabelCache.getSystemEntityVo(jsonObject.getString("entityName"));
		Gson gson = new GsonBuilder()
        .setExclusionStrategies(new ExclusionStrategy() {
			
			@Override
			public boolean shouldSkipField(FieldAttributes f) {
				return (f.getDeclaringClass() == SystemEntityVo.class && f.getName().equals("parentEntity"));
			}
			
			@Override
			public boolean shouldSkipClass(Class<?> arg0) {
				return false;
			}
		}).create();
		
		String jsonResponse=gson.toJson(systemEntityVo, SystemEntityVo.class);
		
		JSONObject returnObj=new JSONObject(jsonResponse);
		System.out.println("APSystemEntity_Store.getSystemEntityVo(jsonResponse) - " + jsonResponse);
		Map<String, Object> returnDate = new HashMap<String, Object>();
		returnDate.put("systemEntityVo", jsonResponse);
		return returnDate;
	}
}
