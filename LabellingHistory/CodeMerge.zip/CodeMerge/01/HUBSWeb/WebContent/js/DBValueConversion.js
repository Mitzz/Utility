function formatCurrency(value){
	var newVal = Ext.util.Format.number(value,'00,00,00,000.00');
	 return newVal;
}

function formatCurrencyFix(value){
	 var newVal = Ext.util.Format.number(value,'00,00,00,000.0000');
	 return newVal;
}

function formatChkBox(value,meta,record){

	var chkStr='<input type="checkbox" name="chkbox" value="' + value + '" />';
	//alert(record.data.structure_code)
    return chkStr;
	
}

function formatSuspendReqId(value){
	return formatSuspendReqIdData(value);
}

function formatSuspendChkId(value){
	var reqStr = '<input type="checkbox" id="' + value + '" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatReleaseReqId(value){
	//var reqStr = '<A HREF="#">' + value + '</A>';
	return value;
}

function formatReleaseChkId(value){
	var reqStr = '<input type="checkbox" id="' + value + '" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatReleaseChkIdForAuth(value){
	var RArray = value.split("##");
	var reqStr = '<input type="checkbox" value="'+ RArray[1] +'" id="' + RArray[0] + '" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatReleaseReqIdForAuth(value){
	//var reqStr = '<A HREF="#">' + value + '</A>';
	return value;
}

function formatAuthReqId(value,meta,record){
	var RArray = value.split("#");
	var reqId = record.data.checkbox_id;
	var strCode = record.data.structure_code;
	var strEnt = record.data.entity_code;
	var strCountry = record.data.country_code;
	var action = 'modify';
	var reqStr='<A HREF="#" onclick="openInNewWin(\'../LimitSetup.jsp?isOpenForAuth=true&action=' + RArray[0] + '&status=unauth&reqid=' + reqId + '&structureCode=' + strCode + '&entityCode=' + strEnt + '&countryCode=' + strCountry + '&applicationId=' + RArray[1] + '\' , \'\', \'statusbar=no,scrollbars=0,scrollbars=no,toolbars=no,resizable=yes,fullscreen=yes\')">' + reqId + '<a> ';
	return reqStr;
	}

	function formatStrCode(value,meta,record){
	var strCode = record.data.checkbox_id;
	var strEnt = record.data.entity_code;
	var strCountry = record.data.country_code;
	var reqStr = '';
	if(parent.lAction && parent.lAction == 'view'){
		reqStr='<A HREF="#" onclick="openInNewWin(\'../LimitSetup.jsp?action=modify&isView=true&status=auth&structureCode=' + strCode  +  '&entityCode=' + strEnt  + '&countryCode=' + strCountry  + '&applicationId=' + value  + '\' , \'\', \'statusbar=yes,scrollbars=0,scrollbars=no,toolbars=no,resizable=yes\')">' + strCode + '<a>';
	} else {
		reqStr='<A HREF="#" onclick="openInNewWin(\'../LimitSetup.jsp?action=modify&status=auth&structureCode=' + strCode  +  '&entityCode=' + strEnt  + '&countryCode=' + strCountry  + '&applicationId=' + value  + '\' , \'\', \'statusbar=yes,scrollbars=0,scrollbars=no,toolbars=no,resizable=yes\')">' + strCode + '<a>';
	}
	return reqStr;	
	}

function formatUnAuthReqId(value,meta,record){
	var RArray = value.split("#");
	var reqId = record.data.checkbox_id;
	var strCode = record.data.structure_code;
	var strEnt = record.data.entity_code;
	var strCountry = record.data.country_code;
	var reqStr = '';
	if(parent.lAction && parent.lAction == 'view'){
		reqStr='<A HREF="#" onclick="openInNewWin(\'../LimitSetup.jsp?action=' + RArray[0] + '&isView=true&status=unauth&reqid=' + reqId  + '&structureCode=' + strCode + '&entityCode=' + strEnt + '&countryCode=' + strCountry + '&applicationId=' + RArray[1] + '\' , \'\', \'statusbar=no,scrollbars=0,scrollbars=no,toolbars=no,resizable=yes,fullscreen=yes\')">' + reqId + '<a> ';
	} else {
		reqStr='<A HREF="#" onclick="openInNewWin(\'../LimitSetup.jsp?action=' + RArray[0] + '&status=unauth&reqid=' + reqId  + '&structureCode=' + strCode + '&entityCode=' + strEnt + '&countryCode=' + strCountry + '&applicationId=' + RArray[1] + '\' , \'\', \'statusbar=no,scrollbars=0,scrollbars=no,toolbars=no,resizable=yes,fullscreen=yes\')">' + reqId + '<a> ';
	}
	return reqStr;	
	}



function formatTopupChkId(value){
	var reqStr = '<input type="checkbox" id="' + value + '" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}
//Reference Entity Entitlement Starts
function formatReferenceEntitlementReqIdData(value){
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFRefDataEntitlement.jsp?wfaction='+action+'&status=unauth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
	}
function formatRefEntitlementReqId(value){
	var reqStr;
	if(value!="")
		{
		var arrVal=value.split("#");
			reqStr = '<input type="checkbox" id="'+arrVal[0]+'" value="'+arrVal[1]+'" onclick="updateSelectList(this)" name="chkbox"/>';
		}
	return reqStr;
}
function formatReferenceDraftReqIdData(value)
{
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFRefDataEntitlement.jsp?wfaction='+action+'&status=draft&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
}

function formatRefEntitlementRecordId(value){
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'" onclick="updateSelectList(this)" name="chkbox"/>';
		}
	return reqStr;
}
function formatRefEntitlementRecordId(value){
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'" onclick="updateSelectList(this)" name="chkbox"/>';
		}
	return reqStr;
}
function formatReferenceRecordId(value){
	var reqStr = '';
	recordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFRefDataEntitlement.jsp?wfaction='+action+'&status=auth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	return reqStr;	
}
//Reference Entity Entitlement Ends
function formatTopupReqId(value){
	var strValue;
	strValue='<A HREF="#" onclick="">' + value + '<a> ';
	return strValue;
}
function formatDateFix(value){
	var date;
	value = value.substr(0,(value.length-2));
	if(!value){
		return "";
	}
	if (!Ext.isDate(value)) {
		date = Date.parseString(value, 'y-M-d HH:mm:ss');
	}
	//alert(date);  
	//var convertedValue = Ext.util.Format.date(date, 'd/m/y'); Commented as it was leading to alignment issue 
	//return convertedValue;
	
	return value;
}

function formatRequestNum(value){
	searchCriteria = new Array();
	searchCriteria = [
			{'name' : 'LAST_TRAN_UNIQ_REF', 'operator' : '=', 'value' : value}
	]
	searchCriteria = JSON.stringify(searchCriteria);
	
	reqStr='<A HREF="javascript:void(0);" onclick="openInNewWin(\'/LMWeb/StructureSearch.jsp?viewId=34&isGridRender=Y&refrenceNo=' + value + '\', \'\', \'statusbar=no,scrollbars=0,scrollbars=no,toolbars=no,resizable=yes,left=' + (screen.width/6) + ',top=' + (screen.height/6) + ',width=' + (screen.width/4) + ',height=' + (screen.height/4) + '\')">' + value + '</a> ';
	return reqStr;
}

function editTimeCode(value){
	if(value == null || value == 'undefined' || value == undefined || value == 'SYSCODE'){
		return "&nbsp;"
	}else{
		return value;
	}
}


function formatUnBlockChkId(value,meta,record){
	var status = record.data.status;
	var reqStr = '<input type="checkbox" id="' + value + '" value="'+status+'" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatBlockAuthView(value,meta,record){
	return formatBlockAuthViewData(value,meta,record);
	
}

function formatAuthUnBlockChkId(value,meta,record){
	var ref = record.data.refrence_no;
	var action = record.data.action;
	var param = ref+","+action;
	var reqStr = '<input type="checkbox" id="' + value + '" value="'+param+'" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatBlockChkId(value,meta,rec1){
	var refno = rec1.data.refrence_no;
	var action = rec1.data.action;
	var param = refno+","+action;
	//alert(refno);
	//alert('<input type="checkbox" id="' + value + '" value="'+refno+'" onclick="updateSelectList(this)" name="chkbox"/>');
	var reqStr = '<input type="checkbox" id="' + value + '" value="'+param+'" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatEventId(value)
{
	var reqStr = '';
	eventId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFUserEvent.jsp?wfaction='+action+'&status=auth&headermessage=Modify&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+eventId+'<a> ';
	return reqStr;	
}

function formatUserEventReqId(value)
{
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFUserEvent.jsp?wfaction='+action+'&status=auth&headermessage=Modify&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
}

/*function formatViewId(value) // KRISHNA
{
	var reqStr = '';
	var viewId = value;
	reqStr='<A HREF="#" onclick="window.open(\'View.jsp?wfaction='+action+'&status='+status+'&headermessage=Modify&ViewId='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+viewId+'<a> ';
	return reqStr;
}*?

/*function formatWTCode(value) // KRISHNA
{
	var reqStr = '';
	var lWTCode = value;
	reqStr='<A HREF="#" onclick="window.open(\'WidgetType.jsp?wfaction='+action+'&status='+status+'&headermessage=Modify&WidgetTypeCode='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+lWTCode+'<a> ';
	return reqStr;
}*/

/*function formatWWEReqId(value) // KRISHNA
{
	var reqStr = '';
	var lReqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WidgetWorkspaceEnt.jsp?wfaction='+action+'&status='+status+'&headermessage=Modify&ReqId='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+lReqId+'<a> ';
	return reqStr;
}*/

/*function formatWWERecordId(value) // KRISHNA
{
	var reqStr = '';
	var lWWERecordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WidgetWorkspaceEnt.jsp?wfaction='+action+'&status='+status+'&headermessage=Modify&RecordCode='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+lWWERecordId+'<a> ';
	return reqStr;
}*/

/*function formatDictionaryCode(value) // KRISHNA
{
	var reqStr = '';
	var lDictionaryCode = value;
	reqStr='<A HREF="#" onclick="window.open(\'WidgetDictionary.jsp?wfaction='+action+'&status='+status+'&headermessage=Modify&WidgetDictionaryCode='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+lDictionaryCode+'<a> ';
	return reqStr;
}*/

function formatWTName(lWTName,metaObj,record) // KRISHNA
{
	var reqStr = '';
	reqStr='<A HREF="" id="'+record.data.widget_type_code+'" onclick="openWidgetTypeForm(this.id);return false;">'+lWTName+'<a>';
	return reqStr;
}

function formatWTType(value) // KRISHNA
{
	var reqStr = '';
	/*if(value == 'S')
		reqStr = 'System Defined';
	else
		reqStr = 'User Defined';*/
	if(value == 'S')
		reqStr = JSVAR_SYSTEM_DEFINED;
	else
		reqStr = JSVAR_USER_DEFINED;
	return reqStr;
}

function formatWWEWorkspace(lWWEWorkspaceName,metaObj,record) // KRISHNA
{
	var reqStr = '';
	reqStr='<A HREF="" id="'+record.data.recordcode+'" onclick="openWorkspaceEntitlementsForm(this.id,true);return false;">'+lWWEWorkspaceName+'<a>';
	return reqStr;
}

function formatDictionaryName(lDictionaryName,metaObj,record) // KRISHNA
{
	var reqStr = '';
	reqStr='<A HREF="" id="'+record.data.widget_dictionary_code+'" onclick="openWidgetDictionaryForm(this.id);return false;">'+lDictionaryName+'<a>';
	return reqStr;
}

function formatViewCode(lViewCode,metaObj,record) // KRISHNA
{
	var reqStr = '';
	reqStr='<A HREF="" id="'+record.data.view_id+'" onclick="openViewForm(this.id);return false;">'+lViewCode+'<a>';
	return reqStr;
}

function formatWWEReqId(lReqId) // KRISHNA
{
	var reqStr = '';
	reqStr='<A HREF="" id="'+lReqId+'" onclick="openWorkspaceEntitlementsForm(this.id,false);return false;">'+lReqId+'<a>';
	return reqStr;
}

function formatComponentCode(value,meta,record) 
{ 
	var reqStr = '';
	var lComponentCode = value;
	var lAppId = record.data.app_id;
	reqStr='<A HREF="#" onclick="window.open(\'ComponentDefinition.jsp?action='+action+'&status='+status+'&headermessage=Modify&applicationId='+lAppId+'&componentCode='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=700,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+lComponentCode+'<a> ';
	return reqStr;
}
//Application Maintenance Changes Starts

function formatApplicationReqIdData(value){
	var reqStr = '';
	reqId = value;
	//reqStr='<A HREF="#" onclick="window.open(\'WFApplicationMaintenance.jsp?wfaction='+action+'&status=unauth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
	}
function formatApplicationReqId(value){
	var reqStr;
	if(value!="")
		{
		var arrVal=value.split("#");
			reqStr = '<input type="checkbox" id="'+arrVal[0]+'" value="'+arrVal[1]+'" name="chkbox"/>';
		}
	return reqStr;
}
function formatApplicationDraftReqIdData(value)
{
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFApplicationMaintenance.jsp?wfaction='+action+'&status=draft&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
}

function formatApplicationId(value){
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'" name="chkbox"/>';
		}
	return reqStr;
}
function formatApplicationRecordId(value){
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'"  name="chkbox"/>';
		}
	return reqStr;
}
function formatApplicationIdValue(value){
	var reqStr = '';
	recordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFApplicationMaintenance.jsp?wfaction='+action+'&status=auth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	return reqStr;	
}

function formatLabelAuditIdValue(value){
	var reqStr = '';
	var labelAuditId = value;
	reqStr='<a href="#" onclick="window.open(\'LabellingAuditDetails.jsp?labelAuditId='+labelAuditId+'&status=auth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+labelAuditId+'</a> ';
	return reqStr;	
}

//Application Maintenance Changes Ends

//Field Entitlement start


function formatFieldEntitlementChkId(value,meta,record){
	var action = record.data.action;
	var reqStr = '<input type="checkbox" id="' + value + '" value="'+ action +'" onclick="updateSelectList(this)" name="chkbox"/>';
	return reqStr;
}

function formatFieldEntitlementReqId(value){
	return formatFieldEntitlementReqIdData(value);
}



function formatFieldEntitlementReqIdData(value){
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFFieldEntitlementsExt.jsp?wfaction=' + lAction+ '&status=unauth&reqid=' + value +'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	//alert("reqid: "+reqStr);
	return reqStr;	
	}

	function formatFieldEntitlementRecordId(value){
	return formatFieldEntitlementRecordIdData(value);
}


function formatFieldEntitlementRecordIdData(value){
	var reqStr = '';
	var recordId= value;
	
	reqStr='<A HREF="#" onclick="window.open(\'WFFieldEntitlementsExt.jsp?wfaction=' + lAction+ '&status=auth&recordId=' + value +'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	//alert("recordid: "+reqStr);
	return reqStr;	
	}

function formatFieldEntitlementDraftData(value){
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFFieldEntitlementsExt.jsp?wfaction=' + lAction+ '&status=draft&reqid=' + value +'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	//alert("reqid: "+reqStr);
	return reqStr;	
	}
//Field Entitlement End

//Enquiry Entitlement start
function formatEnquiryEntitlementReqIdData(value){
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFEnquiryEntitlement.jsp?wfaction='+action+'&status=unauth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
	}

	function formatEnquiryRecordId(value){
	var reqStr = '';
	recordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFEnquiryEntitlement.jsp?wfaction='+action+'&status=auth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	return reqStr;	
}


function formatEnqEntitlementReqId(value){
	var reqStr;
	if(value!="")
		{
		var arrVal=value.split("#");
			reqStr = '<input type="checkbox" id="'+arrVal[0]+'" value="'+arrVal[1]+'" onclick="updateSelectList(this)" name="chkbox"/>';
		}
	return reqStr;
}

function formatEnqEntitlementRecordId(value){
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'" onclick="updateSelectList(this)" name="chkbox"/>';
		}
	return reqStr;
}

//Added by Amit 11-May-2015
function formatChartRecordId(value)
{
    	var reqStr = '';
	recordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFChart.jsp?wfaction='+action+'&status=auth&recordId='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	return reqStr;	

}

//Added by Amit  02-Feb-2016
function formatInProcessChkBox(value)
{
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'" onclick="" name="chkbox"/>';
		}
	return reqStr;
}

function formachartModRecordId(value)
{
    	var reqStr;
	if(value!="")
		{
		//var arrVal=value.split("#");
			reqStr = '<input type="checkbox" id="'+value+'" value="'+action+'" onclick="updateSelectList(this)" name="chkbox"/>';
		}
	return reqStr;

}

function formatEnquiryDraftReqIdData(value)
{
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFEnquiryEntitlement.jsp?wfaction='+action+'&status=draft&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
}

//Enquiry Entitlement End

function formatTemplateCodeValue(value){
	var reqStr = '';
	recordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'LGTemplate.jsp?wfaction='+action+'&status=auth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	return reqStr;	
}

function formatTemplateFormat(value){
	if(value == 1)
	{
		  return 'Plain';
	}
	else if(value == 2)
	{
		 return 'Formated';
	}
	else{
		 return "";
	}
	
}

//Business Event start
function formatEventCode(value,meta,record) 
{ 
	var reqStr = '';
	var lEventCode = value;
	var lAppId = record.data.app_id;
	reqStr='<A HREF="#" onclick="window.open(\'WFBusinessEvent.jsp?action='+action+'&status='+status+'&headermessage=Modify&applicationId='+lAppId+'&eventCode='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=700,width=1100,screenX=0,screenY=0,left=150,top=60\')">'+lEventCode+'<a> ';
	return reqStr;
}

//Business Event end

// Queue/Stage Maintenance Starts
function formatQueueDetails(value,meta,record) 
{ 
	var reqStr = 'NA';
	var lQueueId,lQueueLabel,lTaskId,lTaskLabel,lProcessId,lProcessLabel,lApplicationid,lElementKey;
	if(record && record.data)
	{
	lQueueId = record.data.queueid;
	lQueueLabel = record.data.queuelabel;	
	lTaskId = record.data.taskid;
	lTaskLabel= record.data.tasklabel;
	lProcessId = record.data.processid;
	lProcessLabel= record.data.processlabel;
	lApplicationid = record.data.applicationid;
	lElementKey = record.data.processid+'_'+record.data.taskid+'_'+record.data.queueid;
	reqStr='<A HREF="#" onclick="window.open(\'QueueDefinition.jsp?action='+action+'&headermessage=Modify&applicationId='+lApplicationid+'&queueId='+lQueueId+'&queueLabel='+lQueueLabel+'&taskId='+lTaskId+'&taskLabel='+lTaskLabel+'&processId='+lProcessId+'&processLabel='+lProcessLabel+'&elementKey='+lElementKey+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=400,width=500,screenX=0,screenY=0,left=150,top=60\')">'+lQueueLabel+'</a>';
	}
	return reqStr;
}

function formatTaskDetails(value,meta,record) 
{ 
	var reqStr = 'NA';
	var lTaskId,lTaskLabel,lProcessId,lProcessLabel,lApplicationid,lElementKey;
	if(record && record.data)
	{	
	lTaskId = record.data.taskid;
	lTaskLabel= record.data.tasklabel;
	lProcessId = record.data.processid;
	lProcessLabel= record.data.processlabel;
	lApplicationid = record.data.applicationid;
	lElementKey = record.data.processid+'_'+record.data.taskid;
	reqStr='<A HREF="#" onclick="window.open(\'StageDefinition.jsp?action='+action+'&headermessage=Modify&applicationId='+lApplicationid+'&taskId='+lTaskId+'&taskLabel='+lTaskLabel+'&processId='+lProcessId+'&processLabel='+lProcessLabel+'&elementKey='+lElementKey+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=400,width=500,screenX=0,screenY=0,left=150,top=60\')">'+lTaskLabel+'</a>';
	}
	return reqStr;
}
// Queue/Stage Maintenance Ends
function formatApplicationId(value)
{
	if(value == '0')
    return '';
	else return value;
}
//Scanning Template -- START
function formatScanningTemplateId(value){
	
	var reqStr = '';
	var templateCode = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFScanningTemplate.jsp?wfaction='+action+'&templateCode='+templateCode+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+templateCode+'<a> ';
	return reqStr;	
}
function formatAutoCropAndRotateId(value){
	
	var reqStr = '';
	var code = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFAutoCropAndRotateFrame.jsp?wfaction='+action+'&code='+code+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1250,screenX=0,screenY=0,left=60,top=60\')">'+code+'<a> ';
	return reqStr;	
}
// Scanning Template --END
// Scanning Download XmlData - start
function loadXMLData(value){
	var versionNo = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFScanningSetupDownloadXMLData.jsp?data='+versionNo+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=yes,scrollbars=yes,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1250,screenX=0,screenY=0,left=60,top=60\')">'+versionNo+'<a> ';
	return reqStr;
}
// Scanning Download XmlData - end


// Resume Suspend start
function formatResumeSusReqIdData(value){
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFResumeSuspend.jsp?wfaction='+action+'&status=unauth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
	}
function formatResumeSusReqId(value){
	var reqStr;
	if(value!="")
		{
		var arrVal=value.split("#");
			reqStr = '<input type="checkbox" id="'+arrVal[0]+'" value="'+arrVal[1]+'" name="chkbox"/>';
		}
	return reqStr;
}
function formatResumeSusDraftReqIdData(value)
{
	var reqStr = '';
	reqId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFResumeSuspend.jsp?wfaction='+action+'&status=draft&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	return reqStr;	
}

function formatResumeSusId(value){
	var reqStr;
	if(value!="")
		{
			reqStr = '<input type="checkbox" id="'+value+'" value="'+value+'" name="chkbox"/>';
		}
	return reqStr;
}

function formatResumeSusIdValue(value){
	var reqStr = '';
	recordId = value;
	reqStr='<A HREF="#" onclick="window.open(\'WFResumeSuspend.jsp?wfaction='+action+'&status=auth&reqid='+value+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+recordId+'<a> ';
	return reqStr;	
}

function formatSusTypeId(value){
	var reqStr;
	if(value == "1")
		reqStr = 'Process';
	else 
		reqStr = 'Stage';		
	return reqStr;
	
}

function f1(idName){
	var id= idName.split("#")[0];
	var name = idName.split("#")[1];
//	console.log("Archival Name: " + name);
//	console.log("Id: " + id)
	reqStr='<A HREF="#" onclick="window.open(\'ArchivalPurgingDefinition.jsp?isArchive='+isArchive+'&archivalId='+id+'&wfaction='+wfaction+'&status=auth&archivalName='+name+'\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+name+'<a> ';
	
	return reqStr;	
}



function f2(reqId){
	if(status == "unauth"){
		return reqId;
	}
	reqStr='<A HREF="#" onclick="window.open(\'ArchivalPurgingDefinition.jsp?isArchive='+isArchive+'&reqId='+reqId+'&wfaction='+wfaction+'&status=unauth\',\'\',\'alwaysRaised=yes,dependent=no,directories=no,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,statusbar=no,status=no,toolbar=no,titlebar=no,height=585,width=1100,screenX=0,screenY=0,left=205,top=60\')">'+reqId+'<a> ';
	
	return reqStr;	
}

function f3(idName){
	var id= idName.split("#")[0];
	var name = idName.split("#")[1];
//	console.log("Archival Name: " + name);
//	console.log("Id: " + id)
	reqStr=name;
	
	return reqStr;	
}
// Resume suspend end

function formatDataSource(dataSource){
	console.log(dataSource);
	var value = "";
	if(dataSource == "db") value = "Database";
	if(dataSource == "file") value = "File";
	if(dataSource == "db,file") value = "DB + File";
	return value;
}