package com.polaris.workflow.archive.entity;

import com.polaris.genericmaint.annotation.definition.AutoAuthorize;
import com.polaris.genericmaint.annotation.definition.ColumnInfo;
import com.polaris.genericmaint.annotation.definition.PrimaryKey;
import com.polaris.genericmaint.annotation.definition.Table;
import com.polaris.genericmaint.entityBeans.Entity;

@AutoAuthorize
@Table(tableName = "AP_ARCH_PURGE_MAPPING")
public class APSchedulerMappingEntity extends Entity{

	@PrimaryKey
	@ColumnInfo(columnName = "ID")
	private int id;

	@ColumnInfo(columnName = "AP_DEFINITION_ID")
	private long apDefinitionId;
	
	@ColumnInfo(columnName = "SCHEDULER_ID")
	private long schedulerId;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getApDefinitionId() {
		return apDefinitionId;
	}

	public void setApDefinitionId(long apDefinitionId) {
		this.apDefinitionId = apDefinitionId;
	}

	public long getSchedulerId() {
		return schedulerId;
	}

	public void setSchedulerId(long schedulerId) {
		this.schedulerId = schedulerId;
	}

	@Override
	public String toString() {
		return "APSchedulerMappingEntity [id=" + id + ", apDefinitionId="
				+ apDefinitionId + ", schedulerId=" + schedulerId + "]";
	}
	
	
}
