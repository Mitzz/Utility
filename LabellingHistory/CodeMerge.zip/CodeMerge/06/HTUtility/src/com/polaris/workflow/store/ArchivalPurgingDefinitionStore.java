package com.polaris.workflow.store;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.polaris.genericmaint.exceptions.FrameWorkBaseExceptions;
import com.polaris.genericmaint.exceptions.FrameWorkBusinessException;
import com.polaris.genericmaint.exceptions.FrameWorkSystemException;
import com.polaris.genericmaint.store.GenericStore;
import com.polaris.genericmaint.tools.GenFrmWorkConstant;
import com.polaris.tools.CachingServiceLocator;
import com.polaris.tools.DBResourceUtil;
import com.polaris.tools.ServiceLocator;
import com.polaris.workflow.tools.HashCodeUtility;
import com.polaris.workflow.tools.WFLogger;
import com.polaris.workflow.tools.WFMaintConstants;

public class ArchivalPurgingDefinitionStore extends GenericStore{
	private static WFLogger logger = WFLogger.getInstance((ArchivalPurgingDefinitionStore.class).getName());
	
	public Map authorizeArchivalEntity(Map inputMap){
		HashMap returnMap = new HashMap();		
		try {
			if (logger.isDebugEnabled()) {
	            logger.debug("Inside authorizeAplicationMaintenance  ");
	        }
			JSONObject resultJSON = null;
			StringBuffer sb = new StringBuffer();
			String applicationEntityJSONStr = (String)inputMap.get("data");
			JSONArray ApplicationMaintJSONArray = new JSONArray(applicationEntityJSONStr);
			GenericStore genericStore = new GenericStore();
			if(applicationEntityJSONStr == null){
				sb.append("Request JSON string is empty.");
			} else {
				if(ApplicationMaintJSONArray != null && ApplicationMaintJSONArray.length()>0){
					for (int i=0; i<ApplicationMaintJSONArray.length(); i++) {
						//seqId = getNextSequenceId(connection, eMappingInfo.getSequenceName());
						JSONObject jsonObj=(JSONObject)ApplicationMaintJSONArray.get(i);
						JSONObject jsonEntityData=(JSONObject)jsonObj.get("entityData");
						String reqId=(String)jsonEntityData.getString("reqId");
						String id = (String)jsonEntityData.getString("id");
						Map<String, Object> colNameToColValue = new HashMap<String, Object>();
						colNameToColValue.put("REQID", Integer.parseInt(reqId));
						String ruleInJSON = getClobAsString(colNameToColValue, "AP_ARCH_PURGE_DEF_WORK", "ENTITY_RULE_JSON");
						
						resultJSON = genericStore.invokeOperation((JSONObject)ApplicationMaintJSONArray.get(i));
						colNameToColValue = new HashMap<String, Object>();
						colNameToColValue.put("ID", Integer.parseInt(id));
						updateRuleJsonInClob(colNameToColValue, ruleInJSON, "AP_ARCH_PURGE_DEF", "ENTITY_RULE_JSON");
						if(resultJSON != null){
							sb.append("<br/>"+ "REQID "+reqId+": "+ resultJSON.getString(GenFrmWorkConstant.MESSAGE));
							/*if(resultJSON.has("id")){
								sb.append(" Generated Id: " + resultJSON.getInt("id"));
							}*/
						}
						
					}
				}
			}
			returnMap.put(GenFrmWorkConstant.MESSAGE, sb.toString());
		}catch (FrameWorkBaseExceptions sqex) {
			returnMap.put(GenFrmWorkConstant.MESSAGE, sqex.getMessage());
			logger.fatal("SqlException occurred in authorizeAplicationMaintenance", sqex);
		} 
		catch (Exception ex) {
			returnMap.put(GenFrmWorkConstant.MESSAGE, ex.getMessage());
			logger.fatal("Exception occurred in authorizeAplicationMaintenance", ex);
		}
		finally{
			//DBResourceUtil.closeResource(connection);
		}
		return returnMap;
	}
	
	public Map getUnauthorizedRecord(Map inputMap)  throws FrameWorkSystemException , FrameWorkBusinessException{
		logger.debug("Insi inputMap = " + inputMap);
		
		Map returnMap = new HashMap();		
		try {
			JSONObject unauthorizedRecordJSON = null;
			String requestData = (String)inputMap.get("data");
			JSONObject requestDataJson = new JSONObject(requestData);
			
			JSONObject entityData = (JSONObject)requestDataJson.get(WFMaintConstants.ENTITY_DATA);
			
			String entityName = requestDataJson.getString(WFMaintConstants.ENTITYNAME);
			int reqId = Integer.parseInt(entityData.getString(WFMaintConstants.REQUESTID));
			unauthorizedRecordJSON = getUnauthorizedRecord(entityName, reqId);
			JSONObject unauthorizedEntityDataJSON = (JSONObject)unauthorizedRecordJSON.get(GenFrmWorkConstant.DATA);
			Map<String, Object> colNameToColValue = new HashMap<String, Object>();
			colNameToColValue.put("REQID", reqId);
			String ruleInJSON = getClobAsString(colNameToColValue, "AP_ARCH_PURGE_DEF_WORK", "ENTITY_RULE_JSON");
			unauthorizedEntityDataJSON.put("archivalEntityRuleGrid", ruleInJSON);
			unauthorizedRecordJSON.put(GenFrmWorkConstant.DATA, unauthorizedEntityDataJSON);
			returnMap.put(GenFrmWorkConstant.MESSAGE, "Success");
			returnMap.put("data", unauthorizedEntityDataJSON.toString());
		} 
		catch (Exception ex) 
		{
			logger.fatal("Exception occured insertIntoWorkTable " + ex);
			Object[] objects = {ex.getMessage()};
			throw new FrameWorkSystemException(this.getClass(), "HUBS_FWK_SYS_H_001", objects, ex);
		}
		
		logger.debug("Leaving returnMap = " + returnMap);
		return returnMap;
	}
	
	public Map getAuthorizedRecord(Map inputMap)  throws FrameWorkSystemException , FrameWorkBusinessException{
		logger.debug("Insi inputMap = " + inputMap);
		
		Map returnMap = new HashMap();		
		try {
			JSONObject authorizedRecordJSON = null;
			String requestData = (String)inputMap.get("data");
			JSONObject requestDataJson=new JSONObject(requestData);
			
			authorizedRecordJSON = getAuthorizedRecord(requestDataJson, 0, null, false);
			JSONObject authorizedEntityDataJSON = (JSONObject)authorizedRecordJSON.get(GenFrmWorkConstant.DATA);
			Map<String, Object> colNameToColValue = new HashMap<String, Object>();
			colNameToColValue.put("Id", authorizedEntityDataJSON.get("id"));
			String ruleInJSON = getClobAsString(colNameToColValue, "AP_ARCH_PURGE_DEF", "ENTITY_RULE_JSON");
			authorizedEntityDataJSON.put("archivalEntityRuleGrid", ruleInJSON);
			authorizedRecordJSON.put(GenFrmWorkConstant.DATA, authorizedEntityDataJSON);
			returnMap.put(GenFrmWorkConstant.MESSAGE, "Success");
			returnMap.put("data", authorizedEntityDataJSON.toString());
		} 
		catch (Exception ex) 
		{
			logger.fatal("Exception occured insertIntoWorkTable " + ex);
			Object[] objects = {ex.getMessage()};
			throw new FrameWorkSystemException(this.getClass(), "HUBS_FWK_SYS_H_001", objects, ex);
		}
		
		logger.debug("Leaving returnMap = " + returnMap);
		return returnMap;
	}
	
	public Map insertIntoWorkTable(Map inputMap) throws FrameWorkSystemException , FrameWorkBusinessException
	{
		logger.debug("Inside inputMap = " + inputMap);
		
		HashMap returnMap = new HashMap();		
		try {
			JSONObject resultJSON = null;
			StringBuffer sb = new StringBuffer();
			String applicationData = (String)inputMap.get("data");
			JSONObject applicationEntityData=new JSONObject(applicationData);
			if(applicationEntityData == null)
				throw new FrameWorkBusinessException(this.getClass(),"HUBS_FWK_BSN_H_104",new Throwable()); //## Vivek :: Put proper error code
			
			JSONObject entityData=(JSONObject)applicationEntityData.get(WFMaintConstants.ENTITY_DATA);
			int archivalDefinitionId = -1;
			String eventCode = (String)entityData.get("name");
			archivalDefinitionId = HashCodeUtility.getHashCode(eventCode);
			
			JSONArray ruleJSON = (JSONArray) entityData.get("archivalEntityRuleGrid");
			System.out.println(ruleJSON);
			entityData.put("id", archivalDefinitionId);	
			applicationEntityData.put(WFMaintConstants.ENTITY_DATA , entityData);
			
//			Map<String, String> map = new HashMap<String, String>();
//			map.put(GenFrmWorkConstant.MESSAGE, "Succc");
//			JSONObject jsonObject = new JSONObject(map);
			resultJSON = invokeOperation(applicationEntityData);
//			resultJSON = jsonObject;
			Map<String, Object> columnNameToColumnValue = new HashMap<String, Object>();
			columnNameToColumnValue.put("id", archivalDefinitionId);
			updateRuleJsonInClob(columnNameToColumnValue, ruleJSON.toString(), "AP_ARCH_PURGE_DEF_WORK", "ENTITY_RULE_JSON");
			if(resultJSON != null){
				sb.append("<br/>" + resultJSON.getString(GenFrmWorkConstant.MESSAGE));
			}
		
			if(sb.length() > 0){
				returnMap.put(GenFrmWorkConstant.MESSAGE, sb.toString());
			}
			
			returnMap.put(GenFrmWorkConstant.MESSAGE, sb.toString());
			
		} 
		catch(FrameWorkBusinessException ex)
		{
			logger.fatal("FrameWorkBaseExceptions " + ex);
			throw ex;
		}
		catch (Exception ex) 
		{
			logger.fatal("Exception occured insertIntoWorkTable " + ex);
			Object[] objects = {ex.getMessage()};
			throw new FrameWorkSystemException(this.getClass(), "HUBS_FWK_SYS_H_001", objects, ex);
		}
		
		logger.debug("Leaving inputMap = " + inputMap);
		return returnMap;
	}
	
	public Map deleteAplicationMaintenance(Map inputMap) throws Exception {		
		HashMap returnMap = new HashMap();		
		try {
			if (logger.isDebugEnabled()) {
	            logger.debug("Inside deleteAplicationMaintenance  ");
	        }
			JSONObject resultJSON = null;
			StringBuffer sb = new StringBuffer();
			String applicationMaintJSONStr = (String)inputMap.get("data");
			JSONArray applicationMaintJSONArray = new JSONArray(applicationMaintJSONStr);
			
			GenericStore genericStore = new GenericStore();
			if(applicationMaintJSONStr == null){
				sb.append("Request JSON string is empty.");
			} else {
				if(applicationMaintJSONArray != null && applicationMaintJSONArray.length()>0){
					for (int i=0; i<applicationMaintJSONArray.length(); i++) {
	
						resultJSON = genericStore.invokeOperation((JSONObject)applicationMaintJSONArray.get(i));
						if(resultJSON != null){
							sb.append("<br/>" + resultJSON.getString(GenFrmWorkConstant.MESSAGE));
							if(resultJSON.has("id")){
								sb.append(" Generated Id: " + resultJSON.getInt("id"));
							}
						}
					}
				}
			}
			returnMap.put(GenFrmWorkConstant.MESSAGE, sb.toString());
		} catch (FrameWorkBaseExceptions sqex) {
			returnMap.put(GenFrmWorkConstant.MESSAGE, sqex.getMessage());
			logger.fatal("SqlException occurred in authorizeAplicationMaintenance", sqex);
		} 
		catch (Exception ex) {
			returnMap.put(GenFrmWorkConstant.MESSAGE, ex.getMessage());
			logger.fatal("Exception occurred in authorizeAplicationMaintenance", ex);
		}
		finally{
		}
		return returnMap;
	}
	
	public Map isNameExist(Map inputMap) throws Exception {		
		HashMap returnMap = new HashMap();		
		try {
			if (logger.isDebugEnabled()) {
	            logger.debug("Inside isNameExist  ");
	        }
			JSONObject resultJSON = null;
			StringBuffer sb = new StringBuffer();
			String data = (String)inputMap.get("data");
			JSONObject jsonObject = new JSONObject(data);
			String name = jsonObject.getString("name");
			returnMap.put(GenFrmWorkConstant.MESSAGE, isNameExist(name, "AP_ARCH_PURGE_DEF_WORK") || isNameExist(name, "AP_ARCH_PURGE_DEF"));
		} catch (Exception ex) {
			returnMap.put(GenFrmWorkConstant.MESSAGE, ex.getMessage());
			logger.fatal("Exception occurred in authorizeAplicationMaintenance", ex);
		}
		
		return returnMap;
	}
	
	private boolean isNameExist(String name, String tableName) throws SQLException, FrameWorkSystemException{
		String query = null;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			query = String.format("SELECT COUNT(1) as COUNT FROM %s WHERE NAME = ?", tableName);
			con = CachingServiceLocator.getInstance().getConnection();
			ps = con.prepareStatement(query);
			
			ps.setString(1, name);
			rs = ps.executeQuery();
			rs.next();
			
			return rs.getInt("COUNT") != 0; 
		} finally {
			try{
				DBResourceUtil.closeResource(rs);
				DBResourceUtil.closeResource(ps);
				DBResourceUtil.closeResource(con);
			}catch(Exception e){
				System.out
						.println("ArchivalPurgingDefinitionStore.isNameExist()");
				logger.fatal("ArchivalPurgingDefinitionStore.isNameExist()", e);				
			}
		}
	}
	
	private String getClobAsString(Map<String, Object> colNameToColValue, String tableName, String columnName) throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "";
		try{
			connection = ServiceLocator.getInstance().getConnection();
			sql = String.format("Select %s from %s WHERE %s", columnName, tableName, getWhereClause(colNameToColValue));
			logger.debug("SQL Query: " + sql);
			preparedStatement = connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				return clobToString(rs.getClob(columnName));
			}
			
		} finally {
			DBResourceUtil.closeResource(rs);
			DBResourceUtil.closeResource(preparedStatement);
			DBResourceUtil.closeResource(connection);
		}
		return null;
	}
	
	private String clobToString(java.sql.Clob data) throws SQLException, IOException
	{
		if(data == null) return null;
	    final StringBuilder sb = new StringBuilder();

	        final Reader         reader = data.getCharacterStream();
	        final BufferedReader br     = new BufferedReader(reader);

	        int b;
	        while(-1 != (b = br.read()))
	        {
	            sb.append((char)b);
	        }

	        br.close();
	    

	    return sb.toString();
	}
	
	private void updateRuleJsonInClob(Map<String, Object> colNameToColValue, String ruleJson, String tableName, String columnName) throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "";
		try{
			connection = ServiceLocator.getInstance().getConnection();
			sql = String.format("UPDATE %s SET %s = ? WHERE %s", tableName, columnName, getWhereClause(colNameToColValue));
			logger.debug("SQL Query: " + sql);
			preparedStatement = connection.prepareStatement(sql);
			setClob(connection, preparedStatement, 1, ruleJson);
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			DBResourceUtil.closeResource(preparedStatement);
			DBResourceUtil.closeResource(connection);
		}
		
	}
	
	private void insertRuleJsonInClob(Map<String, Object> colNameToColValue, String ruleJson, String tableName, String columnName) throws Exception{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String sql = "";
		try{
			connection = ServiceLocator.getInstance().getConnection();
			sql = String.format("INSERT INTO %s(%s) VALUES (?) WHERE %s", tableName, columnName, getWhereClause(colNameToColValue));
			logger.debug("SQL Query: " + sql);
			preparedStatement = connection.prepareStatement(sql);
			setClob(connection, preparedStatement, 1, ruleJson);
			preparedStatement.executeUpdate();
			connection.commit();
		} finally {
			DBResourceUtil.closeResource(preparedStatement);
			DBResourceUtil.closeResource(connection);
		}
		
	}
	
	private Object getWhereClause(Map<String, Object> colNameToColValue) {
		StringBuilder whereClause = new StringBuilder();
		for(String colName: colNameToColValue.keySet()){
			Object value = colNameToColValue.get(colName);
			if(value instanceof Number)
				whereClause.append(String.format("%s = %s and ", colName, value));
			else if (value instanceof String)
				whereClause.append(String.format("%s = '%s' and ", colName, value));
		}
		
		return removeLastPartAfterDelimiter(whereClause.toString(), "and ");
	}
	
	private static String removeLastPartAfterDelimiter(String str, String delimiter) {
		int delimiterLastIndex = str.lastIndexOf(delimiter);
		return (delimiterLastIndex == -1) ? str : str.substring(0, delimiterLastIndex);
	}

	private void setClob(Connection conn, PreparedStatement prepStmt, int index, String s) throws SQLException {
		  
		  Clob clob = conn.createClob();
		  clob.setString(1, s);
		  prepStmt.setClob(index, clob);
		}
}
