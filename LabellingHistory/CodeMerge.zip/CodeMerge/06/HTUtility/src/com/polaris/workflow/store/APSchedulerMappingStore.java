package com.polaris.workflow.store;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.polaris.genericmaint.exceptions.FrameWorkBusinessException;
import com.polaris.genericmaint.exceptions.FrameWorkSystemException;
import com.polaris.genericmaint.store.GenericStore;
import com.polaris.genericmaint.tools.GenFrmWorkConstant;
import com.polaris.tools.CachingServiceLocator;
import com.polaris.tools.DBResourceUtil;
import com.polaris.workflow.tools.HashCodeUtility;
import com.polaris.workflow.tools.WFLogger;
import com.polaris.workflow.tools.WFMaintConstants;

public class APSchedulerMappingStore extends GenericStore {
	private static WFLogger logger = WFLogger.getInstance((APSchedulerMappingStore.class).getName());

	public Map insert(Map inputMap) throws FrameWorkBusinessException, FrameWorkSystemException{
		logger.debug("Inside inputMap = " + inputMap);
		
		HashMap returnMap = new HashMap();		
		try {
			JSONObject resultJSON = null;
			StringBuffer sb = new StringBuffer();
			String applicationData = (String)inputMap.get("data");
			JSONObject applicationEntityData=new JSONObject(applicationData);
			if(applicationEntityData == null)
				throw new FrameWorkBusinessException(this.getClass(),"HUBS_FWK_BSN_H_104",new Throwable()); //## Vivek :: Put proper error code
			
			JSONArray arr = (JSONArray) applicationEntityData.get(WFMaintConstants.ENTITY_DATA);
			for(int i = 0; i < arr.length(); i++)
			{	
				JSONObject entityData=arr.getJSONObject(i);
				int archivalDefinitionId = -1;
				archivalDefinitionId = HashCodeUtility.getHashCode(new Integer(entityData.getInt("schedulerId") + entityData.getInt("apDefinitionId")).toString());
				
				entityData.put("id", archivalDefinitionId);	
				applicationEntityData.put(WFMaintConstants.ENTITY_DATA , entityData);
				
				Map<String, String> map = new HashMap<String, String>();
				map.put(GenFrmWorkConstant.MESSAGE, "Succc");
				JSONObject jsonObject = new JSONObject(map);
				resultJSON = invokeOperation(applicationEntityData);
	//			resultJSON = jsonObject;
				Map<String, Object> columnNameToColumnValue = new HashMap<String, Object>();
				columnNameToColumnValue.put("id", archivalDefinitionId);
				if(resultJSON != null){
					sb.append("<br/>" + resultJSON.getString(GenFrmWorkConstant.MESSAGE));
				}
			}
			if(sb.length() > 0){
				returnMap.put(GenFrmWorkConstant.MESSAGE, sb.toString());
			}
			
			returnMap.put(GenFrmWorkConstant.MESSAGE, sb.toString());
			
		} 
		catch(FrameWorkBusinessException ex)
		{
			logger.fatal("FrameWorkBaseExceptions " + ex);
			throw ex;
		}
		catch (Exception ex) 
		{
			logger.fatal("Exception occured insertIntoWorkTable " + ex);
			Object[] objects = {ex.getMessage()};
			throw new FrameWorkSystemException(this.getClass(), "HUBS_FWK_SYS_H_001", objects, ex);
		}
		
		logger.debug("Leaving inputMap = " + inputMap);
		return returnMap;

	}
	
	public Map delink(Map inputMap) throws FrameWorkBusinessException, FrameWorkSystemException{
		logger.debug("Inside inputMap = " + inputMap);
		
		HashMap returnMap = new HashMap();		
		try {
			String applicationData = (String)inputMap.get("data");
			JSONObject applicationEntityData=new JSONObject(applicationData);
			if(applicationEntityData == null)
				throw new FrameWorkBusinessException(this.getClass(),"HUBS_FWK_BSN_H_104",new Throwable()); //## Vivek :: Put proper error code
			
			JSONArray entityDataArray = applicationEntityData.getJSONArray(WFMaintConstants.ENTITY_DATA);
			List<Integer> ids = new ArrayList<Integer>();
			for(int i = 0; i < entityDataArray.length(); i++) {	
				JSONObject entityData=entityDataArray.getJSONObject(i);
				ids.add(entityData.getInt("id"));
			}
			delink(ids);
			returnMap.put(GenFrmWorkConstant.MESSAGE, ids.size() + " Record(s) Updated Successfully.");
			
		} 
		catch(FrameWorkBusinessException ex)
		{
			logger.fatal("FrameWorkBaseExceptions " + ex);
			throw ex;
		}
		catch (Exception ex) 
		{
			logger.fatal("Exception occured insertIntoWorkTable " + ex);
			Object[] objects = {ex.getMessage()};
			throw new FrameWorkSystemException(this.getClass(), "HUBS_FWK_SYS_H_001", objects, ex);
		}
		
		logger.debug("Leaving inputMap = " + inputMap);
		return returnMap;

	}
	
	public boolean delink(List<Integer> ids) throws FrameWorkSystemException, SQLException{
		String query = null;
		Connection con = null;
		PreparedStatement ps = null;
		try {
			query = "DELETE FROM AP_ARCH_PURGE_MAPPING WHERE ID = ?";
			con = CachingServiceLocator.getInstance().getConnection();
			ps = con.prepareStatement(query);
			
			for(Integer id: ids){
				ps.setInt(1, id);
				ps.executeUpdate();
			}
		} finally {
			try{
				DBResourceUtil.closeResource(ps);
				DBResourceUtil.closeResource(con);
			}catch(Exception e){
				logger.fatal("getUnauthorizedRecord -> Exception while closing resources -> ", e);				
			}
		}
		return true;
	}
}
